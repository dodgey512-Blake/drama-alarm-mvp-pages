package com.dramaalert.android;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

/** Audible background delivery using the same packaged sound ID as foreground playback. */
public final class RingingService extends Service {
    public static final String ACTION_STOP = "com.dramaalert.android.STOP";
    public static final String ACTION_QUIETER = "com.dramaalert.android.QUIETER";
    static final int NOTIFICATION_ID = 801;
    private static final String CHANNEL = "drama_alarm_playback_v1";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private AudioManager audioManager;
    private AudioFocusRequest focus;
    private PowerManager.WakeLock wakeLock;
    private Vibrator vibrator;
    private JSONObject payload;
    private boolean quieter;
    private boolean playbackStarted;
    private boolean destroyed;
    private boolean systemFallback;
    private int playerGeneration;
    private long startedAt;
    private float maximum = .72f;

    static void start(Context context, JSONObject item) {
        Intent intent = new Intent(context, RingingService.class).putExtra(AlarmScheduler.EXTRA_PAYLOAD, item.toString());
        try { context.startForegroundService(intent); }
        catch (RuntimeException e) {
            Log.w("DramaRingingService", "Foreground playback could not start", e);
            AlarmScheduler.prefs(context).edit().putString("error", LocaleText.pick(context,"安卓限制了后台声音，请打开疯狂闹钟。","Android blocked background audio; open Drama Alert Android")).apply();
            showNotification(context, item, true);
        }
    }

    static void showCheck(Context context, JSONObject item) { showNotification(context, item, false); }

    static void channel(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL, LocaleText.pick(context,"闹钟与起床复查","Alarms and wake-up checks"), NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription(LocaleText.pick(context,"闹铃播放、起床确认与随时可用的安全退出","Alarm playback, wake-up confirmation and an always available emergency stop"));
        // MediaPlayer owns sound and vibration. Notification updates must not restart it.
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(channel);
    }

    private static boolean canNotify(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        return manager != null && manager.areNotificationsEnabled() && (Build.VERSION.SDK_INT < 33
                || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
    }

    private static Notification notification(Context context, JSONObject item, boolean ringing) {
        channel(context);
        JSONObject alarm = item.optJSONObject("alarm");
        String defaultLabel = LocaleText.pick(context,"晨间开场","Morning Show");
        String label = alarm == null ? defaultLabel : alarm.optString("label", defaultLabel);
        PendingIntent open = AlarmScheduler.openIntent(context, item);
        Notification.Builder builder = new Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(ringing ? LocaleText.pick(context,"开场时刻 · ","Showtime · ") + label : LocaleText.pick(context,"已经起床了吗？","Still with us?"))
                .setContentText(ringing ? LocaleText.pick(context,"打开唤醒任务，随时可以安全退出。","Open your wake-up challenge. Emergency stop is always available.")
                        : LocaleText.pick(context,"打开疯狂闹钟，确认已经起床。","Open Drama Alert Android to confirm your wake-up."))
                .setContentIntent(open).setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC).setOnlyAlertOnce(true)
                .setOngoing(ringing).setAutoCancel(!ringing).setShowWhen(true);
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (canNotify(context) && manager != null && (Build.VERSION.SDK_INT < 34 || manager.canUseFullScreenIntent())) {
            builder.setFullScreenIntent(open, true);
        }
        builder.addAction(new Notification.Action.Builder(null, LocaleText.pick(context,"打开任务","Open challenge"), open).build());
        if (ringing) {
            Intent stop = new Intent(context, RingingService.class).setAction(ACTION_STOP)
                    .putExtra(AlarmScheduler.EXTRA_PAYLOAD, item.toString());
            PendingIntent stopIntent = PendingIntent.getService(context, 802, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(new Notification.Action.Builder(null, LocaleText.pick(context,"安全退出","Emergency stop"), stopIntent).build());
        }
        return builder.build();
    }

    private static void showNotification(Context context, JSONObject item, boolean ringing) {
        if (!canNotify(context)) return;
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(NOTIFICATION_ID, notification(context, item, ringing));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_STOP.equals(intent.getAction())) {
            JSONObject event = payload;
            try { if (event == null) event = new JSONObject(intent.getStringExtra(AlarmScheduler.EXTRA_PAYLOAD)); }
            catch (Exception ignored) {}
            if (event != null) AlarmScheduler.emergencyStop(this, event); else AlarmScheduler.stop(this);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_QUIETER.equals(intent.getAction())) {
            quieter = true;
            setVolume(Math.min(maximum, .25f));
            return START_NOT_STICKY;
        }
        try { payload = new JSONObject(intent.getStringExtra(AlarmScheduler.EXTRA_PAYLOAD)); }
        catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
        Notification note = notification(this, payload, true);
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NOTIFICATION_ID, note);
        if (!playbackStarted) {
            playbackStarted = true;
            startedAt = System.currentTimeMillis();
            acquireWakeLock();
            play();
            handler.postDelayed(() -> { AlarmScheduler.stop(this); stopSelf(); }, AlarmScheduler.LATE_WINDOW);
        }
        return START_NOT_STICKY;
    }

    private void acquireWakeLock() {
        PowerManager manager = getSystemService(PowerManager.class);
        if (manager == null) return;
        wakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DramaAlert:AlarmAudio");
        wakeLock.acquire(AlarmScheduler.LATE_WINDOW + 10_000L);
    }

    private void play() {
        JSONObject alarm = payload.optJSONObject("alarm");
        maximum = Math.max(.25f, Math.min(1f, (alarm == null ? 72 : alarm.optInt("maxVolume", 72)) / 100f));
        final boolean rising = alarm == null || alarm.optBoolean("rising", true);
        AudioAttributes attributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        audioManager = getSystemService(AudioManager.class);
        focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attributes).setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener(change -> {
                    if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        try { if (player != null && player.isPlaying()) player.pause(); } catch (IllegalStateException ignored) {}
                    } else if (change == AudioManager.AUDIOFOCUS_GAIN && player != null) {
                        try { player.start(); } catch (IllegalStateException ignored) {}
                    }
                }).build();
        if (audioManager != null && audioManager.requestAudioFocus(focus) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            AlarmScheduler.prefs(this).edit().putString("error", LocaleText.pick(this,"暂时无法取得闹铃音频焦点。","Alarm audio focus was unavailable")).apply();
            return;
        }
        String soundId = alarm == null ? "first-light" : alarm.optString("soundId", "first-light");
        AlarmScheduler.prefs(this).edit().putString("nativeAudioSoundId", soundId)
                .putBoolean("nativeAudioPlaying", false).remove("nativeAudioFallbackReason").apply();
        try { preparePlayer(attributes, rising, soundId, BundledAudioCatalog.assetPath(this, soundId)); }
        catch (Exception error) { fallbackToSystem(attributes, rising, soundId, "bundled-asset-unavailable"); }
        vibrator = getSystemService(Vibrator.class);
        if (vibrator != null && vibrator.hasVibrator()) {
            try { vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 250, 750}, 0), attributes); }
            catch (SecurityException ignored) {}
        }
    }

    private void preparePlayer(AudioAttributes attributes, boolean rising, String soundId, String assetPath) throws Exception {
        releasePlayer();
        if (destroyed) return;
        final int generation = ++playerGeneration;
        final boolean bundled = assetPath != null;
        MediaPlayer next = new MediaPlayer();
        player = next;
        next.setAudioAttributes(attributes);
        if (bundled) {
            try (AssetFileDescriptor file = getAssets().openFd(assetPath)) {
                next.setDataSource(file.getFileDescriptor(), file.getStartOffset(), file.getLength());
            }
        } else {
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            if (sound == null) throw new IllegalStateException("No system alarm sound");
            next.setDataSource(this, sound);
        }
        next.setLooping(true);
        next.setOnPreparedListener(value -> {
            if (destroyed || generation != playerGeneration || value != player) return;
            try {
                setVolume(quieter ? Math.min(maximum, .25f) : rising ? Math.min(.15f, maximum) : maximum);
                value.start();
                AlarmScheduler.prefs(this).edit().putString("nativeAudioSource", bundled ? "bundled" : "system")
                        .putString("nativeAudioAsset", bundled ? assetPath : "")
                        .putString("nativeAudioSoundId", soundId).putInt("nativeAudioDurationMs", value.getDuration())
                        .putBoolean("nativeAudioLooping", value.isLooping())
                        .putBoolean("nativeAudioPlaying", true).apply();
                if (rising) rampVolume();
            } catch (RuntimeException error) {
                if (bundled) fallbackToSystem(attributes, rising, soundId, "bundled-start-failed");
                else playbackFailed();
            }
        });
        next.setOnErrorListener((value, what, extra) -> {
            if (destroyed || generation != playerGeneration || value != player) return true;
            AlarmScheduler.prefs(this).edit().putBoolean("nativeAudioPlaying", false).apply();
            if (bundled) handler.post(() -> {
                if (!destroyed && generation == playerGeneration && value == player)
                    fallbackToSystem(attributes, rising, soundId, "bundled-decode-failed");
            });
            else playbackFailed();
            return true;
        });
        next.prepareAsync();
    }

    private void fallbackToSystem(AudioAttributes attributes, boolean rising, String soundId, String reason) {
        if (destroyed || systemFallback) return;
        systemFallback = true;
        AlarmScheduler.prefs(this).edit().putString("nativeAudioFallbackReason", reason).apply();
        try {
            preparePlayer(attributes, rising, soundId, null);
        } catch (Exception e) {
            releasePlayer();
            playbackFailed();
            Log.w("DramaRingingService", "Default alarm playback failed", e);
        }
    }

    private void playbackFailed() {
        AlarmScheduler.prefs(this).edit().putBoolean("nativeAudioPlaying", false)
                .putString("error", LocaleText.pick(this,"无法播放闹铃，请打开疯狂闹钟检查声音。","Alarm audio could not be played; open Drama Alarm to check sound.")).apply();
    }

    private void releasePlayer() {
        playerGeneration++;
        if (player == null) return;
        MediaPlayer old = player;
        player = null;
        old.setOnPreparedListener(null);
        old.setOnErrorListener(null);
        try { old.stop(); } catch (IllegalStateException ignored) {}
        old.release();
    }

    private void rampVolume() {
        if (player == null || quieter) return;
        float fraction = Math.min(1f, (System.currentTimeMillis() - startedAt) / 30_000f);
        setVolume(Math.min(maximum, .15f + fraction * Math.max(0, maximum - .15f)));
        if (fraction < 1f) handler.postDelayed(this::rampVolume, 500);
    }

    private void setVolume(float value) {
        if (player != null) try { player.setVolume(value, value); } catch (IllegalStateException ignored) {}
    }

    @Override public void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        AlarmScheduler.prefs(this).edit().putBoolean("nativeAudioPlaying", false).apply();
        if (vibrator != null) vibrator.cancel();
        if (audioManager != null && focus != null) audioManager.abandonAudioFocusRequest(focus);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
