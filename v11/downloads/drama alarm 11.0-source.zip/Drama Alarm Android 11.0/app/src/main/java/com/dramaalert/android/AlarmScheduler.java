package com.dramaalert.android;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Native scheduling mirror. Web storage remains the source of business state. */
public final class AlarmScheduler {
    static final String PREFS = "drama_native";
    static final String ACTION_FIRE = "com.dramaalert.android.FIRE";
    static final String EXTRA_PAYLOAD = "payload";
    static final long LATE_WINDOW = 10 * 60_000L;
    private static final String TAG = "DramaAlarmScheduler";
    // Process memory deliberately resets on process death. A persisted foreground=true
    // must never suppress background delivery after Android recreates this process.
    private static volatile boolean foreground;
    private AlarmScheduler() {}

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Reject malformed state before replacing the last usable native schedule. */
    public static synchronized String sync(Context context, String raw) {
        try {
            if (raw == null || raw.length() > 2_000_000) throw new JSONException("Invalid state size");
            JSONObject state = new JSONObject(raw);
            int schema = state.optInt("schemaVersion");
            if ((schema != 11 && schema != 10 && schema != 9 && schema != 8) || !(state.opt("alarms") instanceof JSONArray)
                    || !(state.opt("wakeChecks") instanceof JSONArray)) throw new JSONException("Expected valid alarm state");
            prefs(context).edit().putString("state", raw).putString("language", "en".equals(state.optString("language")) ? "en" : "zh-CN").remove("error").commit();
            RingingService.channel(context);
            reschedule(context);
        } catch (JSONException e) {
            prefs(context).edit().putString("error", LocaleText.pick(context,"原生闹钟状态未能更新，请检查设置后重试。","Native alarm state was not updated. Check settings and try again.")).apply();
            Log.w(TAG, "Rejected invalid state", e);
        }
        return getStatus(context).toString();
    }

    public static synchronized void reschedule(Context context) {
        SharedPreferences preferences = prefs(context);
        AlarmManager manager = context.getSystemService(AlarmManager.class);
        if (manager == null) return;
        List<JSONObject> desired;
        try {
            JSONObject state = new JSONObject(preferences.getString("state", "{}"));
            desired = desired(state, preferences, System.currentTimeMillis());
        } catch (JSONException e) {
            preferences.edit().putString("error", LocaleText.pick(context,"无法读取原生响铃计划。","Native schedule could not be read")).apply();
            return;
        }
        JSONArray previous = array(preferences.getString("scheduled", "[]"));
        for (int i = 0; i < previous.length(); i++) {
            JSONObject item = previous.optJSONObject(i);
            if (item != null) manager.cancel(operation(context, item));
        }
        JSONArray scheduled = new JSONArray();
        if (canSchedule(context)) {
            for (JSONObject item : desired) {
                try {
                    long at = Math.max(System.currentTimeMillis() + 500, item.getLong("scheduledAt"));
                    manager.setAlarmClock(new AlarmManager.AlarmClockInfo(at, openIntent(context, item)), operation(context, item));
                    scheduled.put(item);
                } catch (SecurityException | JSONException | IllegalArgumentException e) {
                    preferences.edit().putString("error", LocaleText.pick(context,"安卓未能安排闹钟，请检查精确闹钟权限。","Android could not schedule an alarm. Check exact alarm access.")).apply();
                    Log.w(TAG, "Alarm scheduling failed", e);
                }
            }
        } else if (!desired.isEmpty()) {
            preferences.edit().putString("error", LocaleText.pick(context,"请允许“闹钟和提醒”，以安排精确闹钟。","Allow Alarms & reminders to schedule exact alarms")).apply();
        }
        preferences.edit().putString("scheduled", scheduled.toString()).commit();
        cancelStaleRinging(context);
    }

    private static List<JSONObject> desired(JSONObject state, SharedPreferences preferences, long now) throws JSONException {
        List<JSONObject> result = new ArrayList<>();
        if (!state.optBoolean("onboarded")) return result;
        Set<String> handled = new HashSet<>();
        JSONArray occurrences = state.optJSONArray("occurrences");
        if (occurrences != null) for (int i = 0; i < occurrences.length(); i++) {
            JSONObject item = occurrences.optJSONObject(i);
            if (item != null) handled.add(item.optString("id"));
        }
        handled.addAll(preferences.getStringSet("fired", new HashSet<>()));
        Set<String> stopped = preferences.getStringSet("stopped", new HashSet<>());
        ZoneId zone = ZoneId.systemDefault();
        LocalDate today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
        // Initial saves must not create catch-up alarms for a time before installation.
        long checked = state.optLong("lastScheduleCheckAt", now);
        long lower = Math.max(now - LATE_WINDOW, Math.min(now, checked <= 0 ? now : checked));
        JSONArray alarms = state.optJSONArray("alarms");
        if (alarms != null) for (int i = 0; i < Math.min(alarms.length(), 200); i++) {
            JSONObject alarm = alarms.optJSONObject(i);
            if (alarm == null || !alarm.optBoolean("enabled") || alarm.optString("id").isEmpty()) continue;
            try {
                String[] time = alarm.optString("time", "06:30").split(":");
                LocalTime localTime = LocalTime.of(Integer.parseInt(time[0]), Integer.parseInt(time[1]));
                JSONObject next = null;
                if ("once".equals(alarm.optString("repeatMode"))) {
                    LocalDate day = LocalDate.parse(alarm.optString("onceDate"));
                    next = candidate(alarm, day, localTime, zone, lower, handled);
                } else {
                    JSONArray days = alarm.optJSONArray("days");
                    // Yesterday covers a valid late event immediately after midnight.
                    for (int offset = -1; offset <= 8; offset++) {
                        LocalDate day = today.plusDays(offset);
                        if (!contains(days, day.getDayOfWeek().getValue() % 7)) continue;
                        JSONObject item = candidate(alarm, day, localTime, zone, lower, handled);
                        if (item != null && (next == null || item.getLong("scheduledAt") < next.getLong("scheduledAt"))) next = item;
                    }
                }
                if (next != null) result.add(next);
            } catch (DateTimeException | NumberFormatException | ArrayIndexOutOfBoundsException ignored) {
                // One corrupt record must not discard other valid alarms.
            }
        }
        JSONObject active = state.optJSONObject("activeSession");
        boolean realAlarmActive = active != null && !"test".equals(active.optString("kind"));
        JSONArray pending = array(preferences.getString("pending", "[]"));
        for (int i = 0; i < pending.length(); i++) {
            JSONObject item = pending.optJSONObject(i);
            if (item != null && "alarm".equals(item.optString("kind"))) realAlarmActive = true;
        }
        JSONArray checks = state.optJSONArray("wakeChecks");
        if (checks != null) for (int i = 0; i < Math.min(checks.length(), 100); i++) {
            JSONObject check = checks.optJSONObject(i);
            if (check == null) continue;
            String status = check.optString("status");
            if (!("pending".equals(status) || "presented".equals(status))) continue;
            if (stopped.contains(check.optString("occurrenceId"))) continue;
            // Official alarm sessions take priority over wake-up follow-ups.
            if (realAlarmActive && !(active != null && "check".equals(active.optString("kind"))
                    && check.optString("occurrenceId").equals(active.optString("occurrenceId")))) continue;
            long due = check.optLong("dueAt");
            if (due <= 0 || now - due > LATE_WINDOW) continue;
            JSONObject alarm = check.optJSONObject("alarm");
            if (alarm == null) continue;
            String id = check.optString("id");
            if (id.isEmpty()) continue;
            if ("pending".equals(status) && !handled.contains("check:" + id)) {
                result.add(checkEvent(check, alarm, "check", due, zone));
            }
            long expires = check.optLong("expiresAt", due + 60_000L);
            if (!handled.contains("check-expired:" + id)) result.add(checkEvent(check, alarm, "check-expired", expires, zone));
        }
        return result;
    }

    private static JSONObject candidate(JSONObject alarm, LocalDate day, LocalTime time, ZoneId zone,
                                        long lower, Set<String> handled) throws JSONException {
        // atZone resolves gaps forward and chooses the earlier offset on overlaps, like JS Date.
        long at = LocalDateTime.of(day, time).atZone(zone).toInstant().toEpochMilli();
        String id = alarm.getString("id") + "@" + at;
        if (at <= lower || handled.contains(id)) return null;
        return event("alarm", id, alarm, at, day.toString(), zone.getId());
    }

    private static JSONObject checkEvent(JSONObject check, JSONObject alarm, String kind, long at, ZoneId zone) throws JSONException {
        JSONObject result = event(kind, check.getString("id"), alarm, at,
                Instant.ofEpochMilli(at).atZone(zone).toLocalDate().toString(), zone.getId());
        result.put("checkId", check.getString("id"));
        result.put("occurrenceId", check.optString("occurrenceId"));
        return result;
    }

    private static JSONObject event(String kind, String id, JSONObject alarm, long at, String day, String zone) throws JSONException {
        return new JSONObject().put("kind", kind).put("id", id).put("alarmId", alarm.optString("id"))
                .put("alarm", alarm).put("scheduledAt", at).put("localDate", day).put("timeZone", zone);
    }

    static String key(JSONObject item) {
        String kind = item.optString("kind");
        return "alarm".equals(kind) ? item.optString("id") : kind + ":" + item.optString("id");
    }

    private static boolean contains(JSONArray values, int wanted) {
        if (values != null) for (int i = 0; i < values.length(); i++) if (values.optInt(i, -1) == wanted) return true;
        return false;
    }

    static JSONArray array(String raw) {
        try { return new JSONArray(raw); } catch (JSONException ignored) { return new JSONArray(); }
    }

    private static PendingIntent operation(Context context, JSONObject item) {
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_FIRE)
                .setData(Uri.parse("dramaalert://alarm/" + Uri.encode(key(item))))
                .putExtra(EXTRA_PAYLOAD, item.toString());
        return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent openIntent(Context context, JSONObject item) {
        Intent intent = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("from_alarm", true);
        return PendingIntent.getActivity(context, 10, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Called only by our non-exported receiver's AlarmManager PendingIntent. */
    static synchronized void fire(Context context, String raw) {
        try {
            JSONObject item = new JSONObject(raw);
            SharedPreferences preferences = prefs(context);
            String id = key(item);
            Set<String> fired = new HashSet<>(preferences.getStringSet("fired", new HashSet<>()));
            if (fired.contains(id)) return;
            boolean current = false;
            JSONArray scheduled = array(preferences.getString("scheduled", "[]"));
            for (int i = 0; i < scheduled.length(); i++) {
                JSONObject expected = scheduled.optJSONObject(i);
                if (expected != null && id.equals(key(expected)) && expected.optLong("scheduledAt") == item.optLong("scheduledAt")) current = true;
            }
            if (!current) return; // Deleted/edited/cancelled or obsolete PendingIntent.
            fired.add(id);
            if (fired.size() > 400) fired.removeIf(value -> !value.equals(id) && timestamp(value) < System.currentTimeMillis() - 9 * 86_400_000L);
            preferences.edit().putStringSet("fired", fired).commit();
            if (System.currentTimeMillis() - item.optLong("scheduledAt") > LATE_WINDOW) { reschedule(context); return; }
            enqueue(context, item);
            if ("check".equals(item.optString("kind"))) {
                RingingService.showCheck(context, item);
            } else if (!foreground) {
                preferences.edit().putString("ringing", item.toString()).commit();
                RingingService.start(context, item);
            }
            // Immediately schedule the next weekly occurrence even if the WebView never opens.
            reschedule(context);
        } catch (JSONException e) { Log.w(TAG, "Invalid alarm payload", e); }
    }

    private static long timestamp(String id) {
        try { return Long.parseLong(id.substring(id.lastIndexOf('@') + 1)); }
        catch (RuntimeException ignored) { return 0; }
    }

    static synchronized void enqueue(Context context, JSONObject event) {
        SharedPreferences preferences = prefs(context);
        JSONArray queue = array(preferences.getString("pending", "[]"));
        JSONArray next = new JSONArray();
        for (int i = Math.max(0, queue.length() - 29); i < queue.length(); i++) {
            JSONObject old = queue.optJSONObject(i);
            if (old != null && !key(old).equals(key(event))) next.put(old);
        }
        next.put(event);
        preferences.edit().putString("pending", next.toString()).commit();
    }

    public static synchronized String consumePending(Context context) {
        SharedPreferences preferences = prefs(context);
        JSONArray queue = array(preferences.getString("pending", "[]"));
        if (queue.length() == 0) return "null";
        Object first = queue.opt(0);
        JSONArray rest = new JSONArray();
        for (int i = 1; i < queue.length(); i++) rest.put(queue.opt(i));
        preferences.edit().putString("pending", rest.toString()).commit();
        return first == null ? "null" : first.toString();
    }

    /** Silence only: pending/future alarms are intentionally unaffected. */
    public static void stop(Context context) {
        prefs(context).edit().remove("ringing").apply();
        context.stopService(new Intent(context, RingingService.class));
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager != null) manager.cancel(RingingService.NOTIFICATION_ID);
    }

    static synchronized void emergencyStop(Context context, JSONObject payload) {
        String occurrence = payload.optString("occurrenceId", payload.optString("id"));
        Set<String> stopped = new HashSet<>(prefs(context).getStringSet("stopped", new HashSet<>()));
        stopped.add(occurrence);
        if (stopped.size() > 300) stopped.removeIf(value -> !value.equals(occurrence) && timestamp(value) < System.currentTimeMillis() - 9 * 86_400_000L);
        prefs(context).edit().putStringSet("stopped", stopped).commit();
        try {
            JSONObject event = new JSONObject(payload.toString()).put("kind", "emergency").put("stoppedAt", System.currentTimeMillis());
            // Remove the original launch event so an emergency stop cannot later launch it again.
            JSONArray queue = array(prefs(context).getString("pending", "[]"));
            JSONArray keep = new JSONArray();
            for (int i = 0; i < queue.length(); i++) {
                JSONObject old = queue.optJSONObject(i);
                if (old != null && !old.optString("id").equals(payload.optString("id"))) keep.put(old);
            }
            prefs(context).edit().putString("pending", keep.toString()).commit();
            enqueue(context, event);
        } catch (JSONException ignored) {}
        stop(context);
    }

    public static void onForeground(Context context) {
        foreground = true;
        prefs(context).edit().putBoolean("foreground", true).apply();
    }

    public static void onBackground(Context context) {
        foreground = false;
        SharedPreferences preferences = prefs(context);
        preferences.edit().putBoolean("foreground", false).apply();
        try {
            JSONObject state = new JSONObject(preferences.getString("state", "{}"));
            JSONObject session = state.optJSONObject("activeSession");
            if (session == null || "test".equals(session.optString("kind")) || session.optBoolean("completed")) return;
            if ("check".equals(session.optString("kind")) && "22".equals(session.optString("phase"))) return;
            String occurrence = session.optString("occurrenceId");
            if (preferences.getStringSet("stopped", new HashSet<>()).contains(occurrence)) return;
            long started = session.optLong("startedAt", System.currentTimeMillis());
            if (System.currentTimeMillis() - started > LATE_WINDOW) return;
            JSONObject alarm = session.optJSONObject("alarm");
            if (alarm == null) return;
            JSONObject event = event("alarm", occurrence.isEmpty() ? session.optString("id") : occurrence,
                    alarm, session.optLong("scheduledAt", started), LocalDate.now().toString(), ZoneId.systemDefault().getId());
            preferences.edit().putString("ringing", event.toString()).commit();
            RingingService.start(context, event);
        } catch (JSONException ignored) {}
    }

    private static void cancelStaleRinging(Context context) {
        SharedPreferences preferences = prefs(context);
        try {
            JSONObject ringing = new JSONObject(preferences.getString("ringing", "null"));
            JSONObject state = new JSONObject(preferences.getString("state", "{}"));
            if (!state.optBoolean("onboarded")) { stop(context); return; }
            String id = ringing.optString("id");
            JSONObject active = state.optJSONObject("activeSession");
            boolean activeMatches = active != null && id.equals(active.optString("occurrenceId"));
            boolean configurationExists = false;
            JSONArray alarms = state.optJSONArray("alarms");
            if (alarms != null) for (int i = 0; i < alarms.length(); i++) {
                JSONObject alarm = alarms.optJSONObject(i);
                if (alarm != null && ringing.optString("alarmId").equals(alarm.optString("id")) && alarm.optBoolean("enabled")) configurationExists = true;
            }
            if ("alarm".equals(ringing.optString("kind")) && !activeMatches && !configurationExists) { stop(context); return; }
            JSONArray occurrences = state.optJSONArray("occurrences");
            if (occurrences != null) for (int i = 0; i < occurrences.length(); i++) {
                JSONObject item = occurrences.optJSONObject(i);
                if (item != null && id.equals(item.optString("id"))) {
                    String status = item.optString("status");
                    if ("challenge_completed".equals(status) || "emergency_stopped".equals(status) || "cancelled".equals(status)) stop(context);
                }
            }
        } catch (JSONException ignored) {}
    }

    public static boolean canSchedule(Context context) {
        AlarmManager manager = context.getSystemService(AlarmManager.class);
        return manager != null && (Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms());
    }

    public static JSONObject getStatus(Context context) {
        JSONObject status = new JSONObject();
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        boolean notifications = manager != null && manager.areNotificationsEnabled()
                && (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
        try {
            status.put("notifications", notifications).put("exactAlarms", canSchedule(context))
                    .put("fullScreenIntent", manager != null && (Build.VERSION.SDK_INT < 34 || manager.canUseFullScreenIntent()))
                    .put("version", BuildConfig.VERSION_NAME).put("scheduledCount", array(prefs(context).getString("scheduled", "[]")).length())
                    .put("error", prefs(context).getString("error", ""));
        } catch (JSONException ignored) {}
        return status;
    }
}
