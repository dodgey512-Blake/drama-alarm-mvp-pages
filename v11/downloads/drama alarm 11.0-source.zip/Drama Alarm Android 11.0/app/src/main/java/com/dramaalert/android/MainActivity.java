package com.dramaalert.android;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.HapticFeedbackConstants;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.WindowInsetsController;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.util.HashMap;
import org.json.JSONObject;

/** Android host for the bundled 11.0 interface. Only the app-owned HTTPS origin has a bridge. */
public class MainActivity extends Activity {
    static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final String HOME = ORIGIN + "/assets/web/index.html";
    private WebView web;
    private FrameLayout root;
    private volatile ThemeChrome chrome;
    private boolean ready;
    private boolean visible;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        // Native padding is the only inset owner. Consuming here prevents the
        // WebView from adding a second safe area on top of the native padding.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int[] padding;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets keyboard = insets.getInsets(WindowInsets.Type.ime());
                padding=ThemeChrome.contentInsets(bars.left,bars.top,bars.right,bars.bottom,keyboard.bottom);
            } else padding=ThemeChrome.contentInsets(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom(),0);
            v.setPadding(padding[0],padding[1],padding[2],padding[3]);
            return Build.VERSION.SDK_INT >= 30 ? WindowInsets.CONSUMED : insets.consumeSystemWindowInsets();
        });
        root.post(root::requestApplyInsets);
        String theme="daybreak";
        try {theme=new JSONObject(AlarmScheduler.prefs(this).getString("state","{}")).optString("themeId","daybreak");} catch (org.json.JSONException ignored) { }
        applyChrome(theme,"content");
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setTextZoom(Math.round(getResources().getConfiguration().fontScale * 100));
        web.setBackgroundColor(Color.TRANSPARENT);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        web.addJavascriptInterface(new Bridge(), "DramaAndroid");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                android.util.Log.d("DramaWeb", message.messageLevel() + ": " + message.message() + " @" + message.lineNumber());
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost()) && uri.getPath() != null && uri.getPath().startsWith("/assets/web/")) {
                    String path = uri.getPath().substring("/assets/".length());
                    if (!path.contains("..") && !path.contains("\\")) {
                        try {
                            String range = null;
                            for (java.util.Map.Entry<String,String> header : request.getRequestHeaders().entrySet())
                                if ("Range".equalsIgnoreCase(header.getKey())) range = header.getValue();
                            return LocalAssetResponse.open(MainActivity.this, path, range);
                        } catch (Exception ignored) { }
                    }
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri.toString().startsWith(ORIGIN + "/assets/web/")) return false;
                if (request.isForMainFrame() && request.hasGesture() && ("https".equals(uri.getScheme()) || "mailto".equals(uri.getScheme()))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        updateAlarmWindow(getIntent());
        web.loadUrl(HOME);
        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this::handleBack);
    }

    @SuppressWarnings("deprecation")
    private void applyChrome(String theme,String mode) {
        chrome=ThemeChrome.resolve(theme,mode);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{chrome.top,chrome.bottom}));
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(chrome.bottom));
        // API 35+ forces transparent system bars. Draw the correct app surface
        // behind them rather than relying on deprecated bar colors alone.
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT>=28) getWindow().setNavigationBarDividerColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT>=29) {getWindow().setStatusBarContrastEnforced(false);getWindow().setNavigationBarContrastEnforced(false);}
        View decor=getWindow().getDecorView();
        int flags=decor.getSystemUiVisibility();
        int legacy=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        decor.setSystemUiVisibility(chrome.lightSurface ? flags|legacy : flags&~legacy);
        if (Build.VERSION.SDK_INT>=30) {
            WindowInsetsController controller=getWindow().getInsetsController();
            if (controller!=null) {
                int appearance=WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(chrome.lightSurface?appearance:0,appearance);
            }
        }
    }

    private void updateAlarmWindow(Intent intent) {
        boolean ringing = intent != null && (intent.getBooleanExtra("from_alarm",false) || intent.hasExtra("alarmId") || intent.hasExtra("payload") || "com.dramaalert.android.RING".equals(intent.getAction()));
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(ringing); setTurnScreenOn(ringing); }
        if (ringing) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); updateAlarmWindow(intent); dispatchResume(); }
    @Override protected void onResume() { super.onResume(); visible = true; if (web != null) { web.onResume(); AlarmScheduler.onForeground(this); dispatchResume(); } }
    @Override protected void onPause() {
        visible = false;
        if (web != null && ready) web.evaluateJavascript("window.DramaAndroidHost && window.DramaAndroidHost.onPause()", ignored -> { if (!visible) AlarmScheduler.onBackground(this); });
        else AlarmScheduler.onBackground(this);
        super.onPause();
    }
    private void dispatchResume() { if (ready && web != null) web.evaluateJavascript("window.DramaAndroidHost && window.DramaAndroidHost.onResume()", null); }
    // API 33+ registers the platform OnBackInvokedDispatcher above. This override
    // is retained only for older Android versions, without an AndroidX dependency.
    @android.annotation.SuppressLint("GestureBackNavigation")
    @Override public void onBackPressed() { handleBack(); }
    private void handleBack() {
        if (!ready) { moveTaskToBack(true); return; }
        web.evaluateJavascript("!!(window.DramaAndroidHost && window.DramaAndroidHost.onBack())", result -> { if (!"true".equals(result)) moveTaskToBack(true); });
    }
    @Override protected void onDestroy() { if (web != null) { web.removeJavascriptInterface("DramaAndroid"); web.destroy(); web = null; } super.onDestroy(); }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) { super.onRequestPermissionsResult(request,permissions,grants); dispatchResume(); }

    public final class Bridge {
        @JavascriptInterface public void updateChrome(String theme,String mode) {
            runOnUiThread(()->{if(root!=null&&web!=null)applyChrome(theme,mode);});
        }
        @JavascriptInterface public String getChromeStatus() {
            ThemeChrome current=chrome;
            if(current==null)return "{}";
            try{return new JSONObject().put("theme",current.theme).put("mode",current.mode).put("top",String.format("#%06X",current.top&0xffffff)).put("bottom",String.format("#%06X",current.bottom&0xffffff)).put("darkIcons",current.lightSurface).toString();}catch(org.json.JSONException ignored){return "{}";}
        }
        @JavascriptInterface public String syncState(String state) {
            if (state == null || state.length() > 2_000_000) return "{\"error\":\"Invalid state\"}";
            AlarmScheduler.sync(MainActivity.this, state);
            try {
                JSONObject session = new JSONObject(state).optJSONObject("activeSession");
                boolean active = session != null && !"test".equals(session.optString("kind")) && !"22".equals(session.optString("phase"));
                runOnUiThread(() -> {
                    if (active) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(active); setTurnScreenOn(active); }
                });
            } catch (org.json.JSONException ignored) { }
            return getStatus();
        }
        @JavascriptInterface public String getStatus() { return AlarmScheduler.getStatus(MainActivity.this).toString(); }
        @JavascriptInterface public void haptic(String cue) {
            // Semantic feedback respects the device's haptic-feedback preference.
            // Never bypass user settings with FLAG_IGNORE_GLOBAL_SETTING.
            final String kind = cue == null ? "click" : cue;
            runOnUiThread(() -> {
                if (web == null || !visible) return;
                int effect = HapticFeedbackConstants.VIRTUAL_KEY;
                if ("selection".equals(kind) || "tick".equals(kind)) effect = HapticFeedbackConstants.CLOCK_TICK;
                if (Build.VERSION.SDK_INT >= 30 && "success".equals(kind)) effect = HapticFeedbackConstants.CONFIRM;
                if (Build.VERSION.SDK_INT >= 30 && "error".equals(kind)) effect = HapticFeedbackConstants.REJECT;
                web.performHapticFeedback(effect);
            });
        }
        @JavascriptInterface public String consumePendingAlarm() { return AlarmScheduler.consumePending(MainActivity.this); }
        @JavascriptInterface public void nativeReady() { runOnUiThread(() -> { ready = true; dispatchResume(); }); }
        @JavascriptInterface public void stopRinging() { AlarmScheduler.stop(MainActivity.this); }
        @JavascriptInterface public void requestPermissions() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) MainActivity.this.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 21);
                else if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager.class).canScheduleExactAlarms()) startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));
                else if (Build.VERSION.SDK_INT >= 34 && !getSystemService(android.app.NotificationManager.class).canUseFullScreenIntent()) startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:"+getPackageName())));
                else Toast.makeText(MainActivity.this,LocaleText.pick(MainActivity.this,"安卓闹钟权限已就绪","Android alarm permissions are ready"),Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void openAlarmSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName()))));
        }
        @JavascriptInterface public void shareDiagnostics(String text) {
            if (text == null || text.length() > 100_000) return;
            runOnUiThread(() -> { Intent share = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,text); startActivity(Intent.createChooser(share,LocaleText.pick(MainActivity.this,"分享诊断信息","Share diagnostics"))); });
        }
    }
}
