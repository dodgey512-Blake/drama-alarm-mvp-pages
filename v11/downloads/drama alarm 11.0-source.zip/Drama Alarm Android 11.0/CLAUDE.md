# 疯狂闹钟 Android 11.0

本目录为11.0独立工程，旧Android10、v10-demo、既有安装包和公开URL保持不变。2026-11-06已完成新11.0构建及API36模拟器64项验收（含Emergency四分支的中英8种确认文案）；正式状态以artifacts/v11和release.json为准，不能使用复制来源的10.0证据宣称11.0已通过。尚未通过实体设备或商店发行验收。

1. 产品源为上级v11-demo/。仅用scripts/sync-v11-web.mjs进行受检三方合并：11.0源为ours，v10-demo/app.js为base，Android10 app.js为native-hooks来源。禁止裸拷app.js，禁止在本目录运行旧版同步器。
2. 应用显示名疯狂闹钟，applicationId com.dramaalert.android，versionCode11，versionName11.0.0。输出dist/drama alarm 11.0.apk；debug签名供安装验证，不是商店发行签名。
3. 原生AlarmManager/Receiver/RingingService继续维护真实调度、通知、安全停铃和后台已选音乐；WebView负责本地业务与交互，不更换框架。SharedPreferences只是调度镜像，不维护另一套题量/付费规则。
4. ThemeChrome使用appearance11四主题的混合后top/cream及挑战plum-2/3深色表面，绘制透明系统栏背后的背景。daybreak top#E4F3EB、velvet top#F3E3ED；开场#701B2E。android.js观察实际html主题、预览、开场和深色场景，取消预览及resume后同步。仅native root消费systemBars/cutout/IME insets；WebView不再次增加safe-area。
5. 默认简体中文，设置切英文。11.0本地存储/schema独立，只读迁移10.0及更早版本，绝不写删历史Web存储。完整业务规则与设计语言以主项目最新release和~/.claude/skills/drama-alarm-design-skill为准。
6. APK必须包含原12首新交付AAC-LC/M4A：6免费/6付费，原soundId/名称/归属/文件字节不变，不带回旧音乐且不重复打包。免费20秒、付费30秒、未购试听6秒；后台原生MediaPlayer播放同一目录选中soundId，失败才用系统闹铃，前台真实播放就绪后交接。原生安全上限10分钟。
7. 构建scripts/build.sh；VM原生桥业务检查node scripts/test-web.mjs；palette/inset纯JDK检查node scripts/test-native-policy.mjs；设备检查DRAMA_ANDROID_SERIAL=emulator-5556 node scripts/accept-v11.mjs。不擦除、重置、卸载或终止其他模拟器；instrumentation在finally恢复原配置，核验10.0和9.0存储未变。
8. 所有验收通过后，先运行node scripts/finalize-v11.mjs写入真实版本状态，再由python3 scripts/package-source.py归档并写外部SHA256SUMS.txt，避免源码ZIP内部自引用散列。源码包排除构建缓存、设备路径、密钥和历史同步器。独立源码包已含本地web资产，可以直接构建；只有包含上级基线的完整工作区才执行三方同步。
9. 模拟器不证明实体设备响度、触感、蓝牙、OEM省电/重启可靠性、TalkBack或商店合规。不把本地支付说明误称已接真实支付或广告。
