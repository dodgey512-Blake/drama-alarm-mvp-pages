# 疯狂闹钟11.0 · Android

本地WebView产品界面与Android原生闹钟调度、通知及后台音乐服务共同组成应用。默认简体中文，可在设置中选择英文。

## 构建与安装

1. 安装包：dist/drama alarm 11.0.apk。
2. Android Studio源码包：dist/drama alarm 11.0-source.zip。
3. applicationId为com.dramaalert.android，versionCode11、versionName11.0.0；可升级安装，不更改现有应用身份。
4. 使用Android Debug Key签名，供安装验证；正式商店签名与实机审核另行进行。

```sh
./scripts/build.sh
DRAMA_ANDROID_SERIAL=emulator-5556 ./scripts/install.sh
node scripts/test-native-policy.mjs
node scripts/test-web.mjs
DRAMA_ANDROID_SERIAL=emulator-5556 node scripts/accept-v11.mjs
node scripts/verify-music-package.mjs
node scripts/finalize-v11.mjs
python3 scripts/package-source.py
```

Gradle Wrapper9.3.1、AGP9.1.1、compileSdk37、targetSdk36，最低API26。构建脚本优先使用本机Android Studio自带JBR；其他电脑在Android Studio配置SDK，不复制本机local.properties。

## 原生与Web的职责

1. 保存闹钟后，将状态镜像到AlarmManager.setAlarmClock。重复规则、队列、已发生事件和复查仍由同一产品状态驱动，native补充系统投递且去重。
2. 后台从APK内目录读取已选soundId对应M4A，原生前台媒体服务循环播放；只有缺失、解码或播放失败才使用系统默认闹铃。前台WebAudio实际开始播放后才交接，紧急停止始终可用。
3. 12首音乐全部本地打包：6首免费、6首额外曲目，保持同一文件、名称及免费/付费归属。免费完整20秒、付费完整30秒；未购试听6秒，音量调节试听6秒。不重复打包WAV、旧旋律或同曲备份。
4. ThemeChrome跟随实际主题/预览/深色挑战和开场，系统栏背景与页面协调，图标按亮暗调整。native root独占安全区处理，WebView不重复增加状态栏/手势区留白。
5. 11.0使用独立存储/schema，只读迁移10.0及更早记录。教学回放和预览不重置已有闹钟与权益。
6. 本地资源来源限定为https://appassets.androidplatform.net/assets/web/，无Internet权限、不加载远程业务代码；M4A响应支持正确MIME和Range。保留现有原生触觉语义，尊重系统开关。
7. 真实商店购买、广告和云端业务尚未接入；界面不伪造交易成功或拥有权益。系统强行停止会阻止后续调度，重新打开后恢复。

## 验收状态

正式证据位于artifacts/v11/。native-policy.json为纯JDK配色/安全区规则测试；web-core-tests.json为隔离原生桥逻辑测试；acceptance.json和instrumentation.log为指定模拟器实测。各范围独立，不合并为所谓全部实机通过。

2026-11-06：49项隔离原生桥业务检查、16项纯JDK策略检查、API36模拟器64项实测均通过；Gradle构建成功，lint为0错误、13项存量警告。真实WebView验证了12曲解码、9套循环跨完整4秒后仍有局部关节变化、6套触摸反馈、53页×4主题、系统栏预览回退和一次安全区、真实AlarmManager投递、后台已选音乐循环及前后台交接、安全停铃。Emergency四分支在中英两语言下的8种文案、STOP输入label/aria和20秒按压说明均复验准确，中文替代确认按钮为“立即停止本次响铃”。测试选择器限定当前screen，避免把170ms非交互退出快照算作第二页。

最终状态读取release.json；旧10.0报告不作为11.0结论。模拟器覆盖不等于实体设备的扬声器、触感、蓝牙、锁屏、省电、重启或OEM可靠性验证。

## 同步与归档

完整项目工作区运行scripts/sync-v11-web.mjs，读取11.0源、10.0Web基线和10.0原生钩子进行受检三方合并；旧工程只读不变。同步失败保留现有已打包资产，并在artifacts/v11记录冲突。独立源码ZIP无需同步即可构建。

设计规则来自主版Drama闹钟design-skill及最新VIS；同页布局、输入和滚动稳定，跨页短透明度交接，三Tab玻璃导航字节保护不变。
