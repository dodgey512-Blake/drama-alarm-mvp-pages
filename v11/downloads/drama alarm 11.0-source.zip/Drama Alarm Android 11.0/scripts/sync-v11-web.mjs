import {readFile,writeFile,cp,readdir,mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {createHash} from 'node:crypto';
const android=path.resolve(import.meta.dirname,'..'),root=path.resolve(android,'..'),source=path.join(root,'v11-demo'),web=path.join(android,'app/src/main/assets/web');
const base=path.join(root,'v10-demo'),native10=path.join(root,'Drama Alarm Android 10.0/app/src/main/assets/web');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function fileHashes(directory,prefix='') {
  const hashes={};
  for(const entry of await readdir(path.join(directory,prefix),{withFileTypes:true})) {
    const relative=path.posix.join(prefix,entry.name);
    if(entry.isDirectory())Object.assign(hashes,await fileHashes(directory,relative));
    else if(entry.isFile())hashes[relative]=sha(await readFile(path.join(directory,relative)));
  }
  return hashes;
}
const sourceFileHashes=await fileHashes(source);
const result=spawnSync('git',['merge-file','-p',path.join(source,'app.js'),path.join(base,'app.js'),path.join(native10,'app.js')],{encoding:'utf8'});
let app=result.stdout;
const resolved=[];
app=app.replace(/^<<<<<<<[^\n]*\n([\s\S]*?)^=======\n([\s\S]*?)^>>>>>>>[^\n]*\n/gm,(block,ours,theirs)=>{
  if(ours.includes('const notificationPermission')&&theirs.includes('const androidStatus')){
    const nativePermission=theirs.match(/      const androidStatus[^\n]*\n      const notificationPermission[^\n]*/)?.[0];
    if(!nativePermission)return block;
    resolved.push('active-session selected music preserved while native permissions are authoritative');
    return ours.replace(/      const notificationPermission[^\n]*/,nativePermission);
  }
  if(ours.includes('diagnostics()')&&theirs.includes('android:window.DramaAndroidHost')){
    resolved.push('versioned diagnostics retains Android permission evidence');
    return ours.replace('language:this.state.language,','language:this.state.language,android:window.DramaAndroidHost?.getStatus(),');
  }
  if(ours.includes('localStorage.setItem("drama-alarm-v11"')&&theirs.includes('window.DramaAndroidHost?.syncState(saved)')){
    resolved.push('schema11 persistence retains native scheduling mirror');
    return ours.replace(/(localStorage\.setItem\("drama-alarm-v11", JSON\.stringify\(saved\)\);)/,'$1\n        const nativeResult = window.DramaAndroidHost?.syncState(saved);\n        this.state.androidScheduleError = nativeResult?.error || "";');
  }
  return block;
});
if(result.status===null||result.status<0||result.status>=128||/^<<<<<<<|^=======|^>>>>>>>/m.test(app)){
  await mkdir(path.join(android,'artifacts/v11'),{recursive:true});
  await writeFile(path.join(android,'artifacts/v11/app-merge-conflicts.txt'),app);
  throw Error('11.0 Android hook merge requires review; existing packaged assets were not replaced.');
}
app=app.replaceAll('Drama Alarm Android 10.0.0','Drama Alarm Android 11.0.0').replaceAll('bundled 10.0 interface','bundled 11.0 interface');
app=app.replace('    acceptNativeAlarm(event) {\n      if (!event || !this.state.onboarded) return false;','    acceptNativeAlarm(event) {\n      if (!event || !this.state.onboarded) return false;\n      if (this.onboardingReplay) this.finishOnboardingReplay({navigate:false});');
app=app.replace('    handleAndroidBack() {','    handleAndroidBack() {\n      if (this.onboardingReplay && this.state.screen === "08") { this.finishOnboardingReplay(); return true; }');
for(const marker of ['acceptNativeAlarm(event)','if (this.onboardingReplay) this.finishOnboardingReplay({navigate:false});','handleAndroidBack()','window.DramaAndroidHost?.syncState(saved)','window.DramaAndroidHost?.ready()','drama-alarm-v11','schemaVersion: 11'])if(!app.includes(marker))throw Error('Missing Android integration: '+marker);
// Preserve native-only adapters. All other web source files are synchronized
// from 11.0, including dynamic motion rigs, translated strings and all 12 M4A.
for(const name of await readdir(source)){
  if(['app.js','index.html','audio.js','offline.js','sw.js','android.js','android-ui.js','android.css'].includes(name))continue;
  await cp(path.join(source,name),path.join(web,name),{recursive:true});
}
await writeFile(path.join(web,'app.js'),app);
let html=await readFile(path.join(source,'index.html'),'utf8');
html=html.replace('</head>','  <link rel="stylesheet" href="android.css">\n</head>')
  .replace('<script src="app.js"></script>','<script src="android.js"></script>\n  <script src="android-ui.js"></script>\n  <script src="app.js"></script>')
  .replace('<script src="offline.js"></script>','').replace(/<body(?:\s+class="([^"]*)")?>/,(_,classes)=>`<body class="${classes?classes+' ':''}android-app-body">`);
if(!html.includes('src="android.js"')||!html.includes('href="android.css"'))throw Error('Android entry-point integration failed');
await writeFile(path.join(web,'index.html'),html);
let audio=await readFile(path.join(source,'audio.js'),'utf8');
const guard='if (!this.context && navigator.userActivation && !navigator.userActivation.hasBeenActive)';
if(!audio.includes(guard))throw Error('Review Android audio gesture guard integration');
audio=audio.replace(guard,'if (!window.DramaAndroidHost?.available && !this.context && navigator.userActivation && !navigator.userActivation.hasBeenActive)');
await writeFile(path.join(web,'audio.js'),audio);
for(const name of ['liquid-glass.js','liquid-glass.css','v7.css'])if(sha(await readFile(path.join(source,name)))!==sha(await readFile(path.join(web,name))))throw Error('Protected visual source changed: '+name);
const catalog=JSON.parse(await readFile(path.join(web,'assets/audio/catalog.json'),'utf8'));
const audioFiles=(await readdir(path.join(web,'assets/audio'))).filter(name=>/\.(?:m4a|wav|mp3|ogg)$/i.test(name));
if(catalog.items.length!==12||audioFiles.length!==12||audioFiles.some(name=>!name.endsWith('.m4a'))||new Set(catalog.items.map(item=>item.src)).size!==12)throw Error('Expected exactly 12 unique current M4A tracks');
for(const item of catalog.items)if(sha(await readFile(path.join(source,item.src)))!==sha(await readFile(path.join(web,item.src))))throw Error('Music bytes changed: '+item.id);
const sourceAfter=await fileHashes(source);
if(Object.keys(sourceAfter).length!==Object.keys(sourceFileHashes).length || Object.entries(sourceFileHashes).some(([name,digest])=>sourceAfter[name]!==digest))throw Error('Web source changed during synchronization; wait for freeze and rerun before building.');
await mkdir(path.join(android,'artifacts/v11'),{recursive:true});
await writeFile(path.join(android,'artifacts/v11/web-sync.json'),JSON.stringify({version:'11.0.0',source:'../v11-demo',threeWayMerge:true,base:'../v10-demo/app.js',nativeHooksFrom:'../Drama Alarm Android 10.0/app/src/main/assets/web/app.js',resolved,oldNativeHooksRetained:true,protectedGlassByteIdentical:true,musicCount:12,musicByteIdentical:true,appSHA:sha(app),webSourceAppSHA:sourceFileHashes['app.js'],sourceFileHashes,nativeFileHashes:await fileHashes(web),syncedAt:new Date().toISOString()},null,2)+'\n');
console.log(JSON.stringify({version:'11.0.0',threeWayMerge:true,protectedGlass:true,music:12,resolved}));
