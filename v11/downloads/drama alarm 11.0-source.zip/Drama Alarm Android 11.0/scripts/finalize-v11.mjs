import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..'),out=path.join(root,'artifacts/v11');
const read=name=>readFile(path.join(out,name),'utf8').then(JSON.parse);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const [sync,music,acceptance,web,policy]=await Promise.all(['web-sync.json','music-package.json','acceptance.json','web-core-tests.json','native-policy.json'].map(read));
assert.equal(sync.webSourceAppSHA,sha(await readFile(path.join(root,'../v11-demo/app.js'))),'Web changed since final synchronization');
assert.equal(sync.appSHA,sha(await readFile(path.join(root,'app/src/main/assets/web/app.js'))),'Native web changed since synchronization');
for(const [name,digest]of Object.entries(sync.sourceFileHashes||{}))assert.equal(digest,sha(await readFile(path.join(root,'../v11-demo',name))),'Web source changed since synchronization: '+name);
for(const [name,digest]of Object.entries(sync.nativeFileHashes||{}))assert.equal(digest,sha(await readFile(path.join(root,'app/src/main/assets/web',name))),'Packaged web asset changed since synchronization: '+name);
assert.equal(sync.threeWayMerge,true);assert.equal(sync.oldNativeHooksRetained,true);
assert.equal(music.musicCount,12);assert.equal(music.legacyOrDuplicateFiles,0);
assert.equal(acceptance.passed,true);assert.equal(web.failed,0);assert.equal(policy.passed,true);
assert.equal(acceptance.mascotLoops.length,9);assert.ok(acceptance.mascotLoops.every(item=>item.jointChanged));assert.equal(acceptance.mascotTouch.length,6);
assert.equal(acceptance.systemChrome.length,4);assert.ok(acceptance.nativeInsets.topPadding>0&&acceptance.nativeInsets.bottomPadding>0);
assert.equal(acceptance.emergencyLocale.length,8);assert.ok(acceptance.emergencyLocale.every(item=>item.valid));
const apkPath=path.join(root,'dist/drama alarm 11.0.apk'),apkSha=sha(await readFile(apkPath));
assert.equal(apkSha,music.apkSha256);assert.equal(apkSha,acceptance.apkSHA256);
// The ZIP includes this release file. Its own digest belongs only in the
// external SHA256SUMS.txt, avoiding a stale/self-referential embedded hash.
const release={productName:'Drama Alarm Android',version:'11.0.0',date:'2026-11-06',status:'emulator-verified-debug',architecture:'Android native AlarmManager/media host + bundled offline WebView',defaultLanguage:'zh-CN',languages:['zh-CN','en'],apk:'dist/drama alarm 11.0.apk',sourceZip:'dist/drama alarm 11.0-source.zip',checksums:'dist/SHA256SUMS.txt',acceptance:'artifacts/v11/acceptance.json',webTests:'artifacts/v11/web-core-tests.json',policyTests:'artifacts/v11/native-policy.json',musicPackage:'artifacts/v11/music-package.json',routeCount:53,themeCount:4,fixedQuestionCount:210,emulator:acceptance.serial+' / API '+acceptance.apiLevel,signing:'Android debug key',realBilling:false,physicalDeviceVerified:false,storeRelease:false,previousVersionPreserved:'../Drama Alarm Android 10.0 and ../v10-demo',musicFiles:12,freeMusic:6,premiumMusic:6,musicFormat:'AAC-LC / M4A / 128kbps / stereo 44.1kHz',freeMusicDurationSeconds:20,premiumMusicDurationSeconds:30,unownedPreviewSeconds:6,legacyMusicFiles:0,legacyMusicSynthesisRemoved:true,emulatorChecks:acceptance.checkCount,webChecks:web.passed,policyChecks:policy.checks,apkBytes:(await readFile(apkPath)).length,apkSha256:apkSha,systemChrome:'Four theme top/bottom surfaces, preview rollback, dark scene icons, native single-owner insets',verifiedAt:new Date().toISOString()};
await writeFile(path.join(root,'release.json'),JSON.stringify(release,null,2)+'\n');console.log(JSON.stringify({version:release.version,status:release.status,emulatorChecks:release.emulatorChecks,apkSha256:apkSha,music:12}));
