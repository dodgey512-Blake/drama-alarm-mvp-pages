#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
drama_sdk_path="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Library/Android/sdk}}"
drama_device="${DRAMA_ANDROID_SERIAL:-}"
drama_adb=("$drama_sdk_path/platform-tools/adb")
if [ -n "$drama_device" ]; then drama_adb+=(-s "$drama_device"); fi
"${drama_adb[@]}" install -r 'dist/drama alarm 11.0.apk'
"${drama_adb[@]}" shell am start -n com.dramaalert.android/.MainActivity
