#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ -z "${JAVA_HOME:-}" ] && [ -d '/Applications/Android Studio.app/Contents/jbr/Contents/Home' ]; then
  export JAVA_HOME='/Applications/Android Studio.app/Contents/jbr/Contents/Home'
fi
./gradlew :app:assembleDebug :app:assembleDebugAndroidTest :app:lintDebug --console=plain
mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk 'dist/drama alarm 11.0.apk'
cp app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk 'dist/drama alarm 11.0-tests.apk'
shasum -a 256 dist/*.apk > dist/SHA256SUMS.txt
