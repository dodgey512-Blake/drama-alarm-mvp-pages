import assert from 'node:assert/strict';
import {readFile,readdir,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..'),project=path.resolve(root,'..');
const web=path.join(root,'app/src/main/assets/web'),source=path.join(project,'v11-demo');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const apk=path.join(root,'dist/drama alarm 11.0.apk');
const sourceOnly=process.argv.includes('--source-only');
const catalog=JSON.parse(await readFile(path.join(web,'assets/audio/catalog.json'),'utf8'));
assert.equal(catalog.items.length,12);assert.equal(catalog.items.filter(item=>item.premium).length,6);assert.equal(catalog.items.filter(item=>!item.premium).length,6);
assert.deepEqual(catalog,JSON.parse(await readFile(path.join(source,'assets/audio/catalog.json'),'utf8')));
assert.equal(new Set(catalog.items.map(item=>item.src)).size,12);
assert.equal(new Set(catalog.items.map(item=>item.id)).size,12);
const files=(await readdir(path.join(web,'assets/audio'))).filter(file=>/\.(m4a|wav|mp3|ogg|aac)$/i.test(file)).sort();
assert.deepEqual(files,catalog.items.map(item=>path.basename(item.src)).sort());
let entries=[];
if(!sourceOnly){const list=spawnSync('unzip',['-Z1',apk],{encoding:'utf8'});assert.equal(list.status,0,list.stderr);entries=list.stdout.trim().split('\n');assert.equal(entries.filter(file=>/\.(m4a|wav|mp3|ogg|aac)$/i.test(file)).length,12,'No legacy or duplicate audio may hide elsewhere in the APK');}
const tracks=[];
for(const item of catalog.items){
 const input=await readFile(path.join(source,item.src)),native=await readFile(path.join(web,item.src));
 assert.equal(sha(native),sha(input));assert.equal(item.duration,item.premium?30:20);
 const name='assets/web/'+item.src;
 if(!sourceOnly){assert.equal(entries.filter(file=>file===name).length,1);const extracted=spawnSync('unzip',['-p',apk,name],{maxBuffer:2_000_000});assert.equal(extracted.status,0);assert.equal(sha(extracted.stdout),sha(input));}
 tracks.push({id:item.id,name:item.name,nameZh:item.nameZh,premium:item.premium,duration:item.duration,src:item.src,bytes:input.length,sha256:sha(input),nativeMatches:true,apkMatches:!sourceOnly});
}
assert.equal(new Set(tracks.map(track=>track.sha256)).size,12,'Tracks must not duplicate the same audio bytes under different names');
const report={version:'11.0.0',status:sourceOnly?'source-verified':'apk-verified',scope:'Exact catalog, filenames, classifications and source/native/APK file bytes. Actual device audio and native decoding are separate checks.',musicCount:12,free:6,premium:6,legacyOrDuplicateFiles:0,apk:sourceOnly?null:path.relative(root,apk),apkSha256:sourceOnly?null:sha(await readFile(apk)),tracks};
const out=path.join(root,'artifacts/v11');await mkdir(out,{recursive:true});await writeFile(path.join(out,sourceOnly?'music-source.json':'music-package.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,tracks:12,free:6,premium:6,duplicates:0}));
