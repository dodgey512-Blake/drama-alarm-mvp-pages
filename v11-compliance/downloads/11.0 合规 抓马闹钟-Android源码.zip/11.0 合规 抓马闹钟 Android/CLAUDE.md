# 11.0 合规 抓马闹钟 Android

本目录是2026-11-07新建的独立副本。源网页为上级 v11-demo，原11.0网页和Android工程受原始SHA清单保护。

1. applicationId 为 com.dramaalert.android.compliance，namespace仍com.dramaalert.android，versionName11.0.0-compliance。输出dist/11.0 合规 抓马闹钟.apk，debug签名。
2. 三方合并由 scripts/sync-compliance-web.mjs 执行，基线为原11.0网页与Android，不得裸覆盖app.js。保留原生调度、生命周期、音频交接、安全退出和系统返回接口。
3. Web主键drama-alarm-v11-compliance，native prefs为drama_native_compliance。重置需调用resetLocalData并清本版native计划/事件，保存无个人数据的初始状态。原版存储只读兼容，不能当作已验证购买来源。
4. notification全屏仅适用于真实ringing，普通check不全屏。导出MainActivity不信任外部from_alarm/payload进行锁屏展示。
5. 12首原M4A及其六免费/六额外归属保持字节不变。原Liquid Glass三个源文件受SHA保护，原9循环与6触摸反馈保留。
6. 正式商店未接入。合规版名称仅表示本轮审查修复，不表示平台审批完成。实体设备和真实购买/广告、逐曲授权、正式签名与控制台申报仍是发行门槛。
7. 构建和验收按README执行，实际结果读本次artifacts/v11。不能沿用原版已通过数字作为本次结果。不得擦除/卸载/改原版应用数据。
