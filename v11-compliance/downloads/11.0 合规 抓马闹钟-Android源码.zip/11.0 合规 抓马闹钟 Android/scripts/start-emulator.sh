#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
drama_sdk_path="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Library/Android/sdk}}"
# Verified on this M2 Mac after the default API 37 snapshot stalled during boot.
# These flags apply only to this invocation; the existing AVD is not rewritten.
exec "$drama_sdk_path/emulator/emulator" -avd "${1:-Medium_Phone_API_37.0}" -no-snapshot-load -gpu host -feature -Vulkan
