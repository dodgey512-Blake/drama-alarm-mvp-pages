import {spawnSync} from 'node:child_process';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..'),out=path.join(root,'artifacts/v11');
const java=process.env.JAVA_HOME||'/Applications/Android Studio.app/Contents/jbr/Contents/Home';
const classes=path.join(out,'policy-classes');await mkdir(classes,{recursive:true});
const source=path.join(root,'app/src/main/java/com/dramaalert/android/ThemeChrome.java');
const checks=path.join(root,'app/src/test/java/com/dramaalert/android/ThemeChromeCheck.java');
for(const [cmd,args]of [[path.join(java,'bin/javac'),['-d',classes,source,checks]],[path.join(java,'bin/java'),['-cp',classes,'com.dramaalert.android.ThemeChromeCheck']]]){
 const result=spawnSync(cmd,args,{encoding:'utf8'});if(result.status!==0)throw Error(result.stderr||result.stdout);if(result.stdout)process.stdout.write(result.stdout);
}
await writeFile(path.join(out,'native-policy.json'),JSON.stringify({version:'11.0.0',passed:true,checks:16,scope:'Plain-JDK approved palette and single-owner safe-area policy; not device pixels or physical display validation',themeChromeSha256:createHash('sha256').update(await readFile(source)).digest('hex'),officialReferences:['https://developer.android.com/develop/ui/views/layout/edge-to-edge'],physicalDeviceVerified:false},null,2)+'\n');
