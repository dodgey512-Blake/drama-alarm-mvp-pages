#!/usr/bin/env python3
"""Create a portable source archive, excluding build/cache/device/private files."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parent.parent
output = root / 'dist' / '11.0 合规 抓马闹钟-Android源码.zip'
excluded = {'.gradle', '.idea', 'build', 'dist', '.git', 'versions', 'artifacts'}
excluded_names = {'local.properties', '.DS_Store', 'emulator.log', 'emulator-coldboot.log'}
excluded_legacy_scripts = {'scripts/sync-v9-web.mjs', 'scripts/sync-v10-web.mjs', 'scripts/sync-v11-web.mjs', 'scripts/finalize-v9.mjs', 'scripts/finalize-v11.mjs', 'scripts/accept-v10.mjs'}
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if not path.is_file() or any(piece in excluded for piece in relative.parts):
            continue
        if path.name in excluded_names or path.suffix in {'.jks', '.keystore'}:
            continue
        if relative.as_posix() in excluded_legacy_scripts:
            continue
        archive.write(path, str(Path('11.0 合规 抓马闹钟 Android') / relative))
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    for required in ('settings.gradle', 'gradlew', 'gradle/wrapper/gradle-wrapper.jar',
                     'app/src/main/AndroidManifest.xml', 'app/src/main/assets/web/index.html'):
        assert '11.0 合规 抓马闹钟 Android/' + required in names
    assert not any(name.endswith('/local.properties') or name.endswith('.keystore') or name.endswith('.jks') for name in names)
    assert not any(name.endswith('/' + legacy) for name in names for legacy in excluded_legacy_scripts)
checksums = []
for name in ('11.0 合规 抓马闹钟.apk', '11.0 合规 抓马闹钟-tests.apk', '11.0 合规 抓马闹钟-Android源码.zip'):
    artifact = root / 'dist' / name
    if artifact.is_file():
        checksums.append(f'{hashlib.sha256(artifact.read_bytes()).hexdigest()}  {name}')
(root / 'dist' / 'SHA256SUMS.txt').write_text('\n'.join(checksums) + '\n')
print(f'{output}: {len(names)} files, {output.stat().st_size} bytes, ZIP verified')
