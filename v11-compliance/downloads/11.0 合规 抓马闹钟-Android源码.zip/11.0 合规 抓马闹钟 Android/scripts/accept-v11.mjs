import {spawn} from 'node:child_process';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const sdk=process.env.ANDROID_SDK_ROOT || process.env.ANDROID_HOME || path.join(os.homedir(),'Library','Android','sdk');
const adb=path.join(sdk,'platform-tools/adb');
const serial=process.env.DRAMA_ANDROID_SERIAL || 'emulator-5556';
const out=path.join(root,'artifacts/v11');
const apk=path.join(root,'dist/11.0 合规 抓马闹钟.apk');
const testApk=path.join(root,'dist/11.0 合规 抓马闹钟-tests.apk');
const report={version:'11.0.0-compliance',startedAt:new Date().toISOString(),serial,passed:false,checks:[],scope:'Real Android emulator AlarmManager/service/WebView acceptance. Physical sound quality, vibration feel and OEM reliability are not certified.'};
await mkdir(out,{recursive:true});
try{const earlier=JSON.parse(await readFile(path.join(out,'acceptance.json'),'utf8'));report.priorAttempts=[...(earlier.priorAttempts||[]),{startedAt:earlier.startedAt,passed:earlier.passed,checks:earlier.checkCount||0,error:earlier.error||null}];}catch{}
async function run(args,{stream=false}={}) {
  return new Promise((resolve,reject)=>{
    const child=spawn(adb,args,{cwd:root});let stdout='',stderr='';
    child.stdout.on('data',data=>{stdout+=data;if(stream)process.stdout.write(data);});
    child.stderr.on('data',data=>{stderr+=data;if(stream)process.stderr.write(data);});
    child.on('error',reject);child.on('close',code=>code===0?resolve(stdout+stderr):reject(new Error(`adb ${args.join(' ')} exited ${code}: ${stdout}\n${stderr}`)));
  });
}
const target=args=>['-s',serial,...args];
try {
  const devices=await run(['devices','-l']);
  if(!devices.split('\n').some(line=>line.split(/\s+/)[0]===serial&&line.split(/\s+/)[1]==='device'))throw Error('Requested emulator is not online; no other device will be selected.');
  report.fingerprint=(await run(target(['shell','getprop','ro.build.fingerprint']))).trim();
  report.apiLevel=Number((await run(target(['shell','getprop','ro.build.version.sdk']))).trim());
  report.apkSHA256=createHash('sha256').update(await readFile(apk)).digest('hex');
  report.testApkSHA256=createHash('sha256').update(await readFile(testApk)).digest('hex');
  const existing=await run(target(['shell','pm','list','packages','com.dramaalert.android.compliance']));
  report.existingInstall=existing.split(/\s+/).includes('package:com.dramaalert.android.compliance');
  // New test installs receive notification permission. Upgrades retain existing
  // permission choices; no data clearing, emulator reset or uninstall is used.
  await run(target(['install','-r',...report.existingInstall?[]:['-g'],apk]),{stream:true});
  await run(target(['install','-r',testApk]),{stream:true});
  const output=await run(target(['shell','am','instrument','-w','-r','com.dramaalert.android.compliance.test/com.dramaalert.android.SmokeInstrumentation']),{stream:true});
  await writeFile(path.join(out,'instrumentation.log'),output);
  const match=output.match(/^INSTRUMENTATION_RESULT: checks=(.*)$/m);
  const layout=output.match(/^INSTRUMENTATION_RESULT: layoutMetrics=(.*)$/m);
  const musicMetadata=output.match(/^INSTRUMENTATION_RESULT: musicMetadata=(.*)$/m);
  const musicDecode=output.match(/^INSTRUMENTATION_RESULT: musicWebDecode=(.*)$/m);
  const chrome=output.match(/^INSTRUMENTATION_RESULT: systemChrome=(.*)$/m);
  const insets=output.match(/^INSTRUMENTATION_RESULT: nativeInsets=(.*)$/m);
  const mascotLoops=output.match(/^INSTRUMENTATION_RESULT: mascotLoops=(.*)$/m);
  const mascotTouch=output.match(/^INSTRUMENTATION_RESULT: mascotTouch=(.*)$/m);
  const emergencyLocale=output.match(/^INSTRUMENTATION_RESULT: emergencyLocale=(.*)$/m);
  report.layoutMetrics=layout?JSON.parse(layout[1]):[];
  report.musicMetadata=musicMetadata?JSON.parse(musicMetadata[1]):[];
  report.musicWebDecode=musicDecode?JSON.parse(musicDecode[1]):null;
  report.systemChrome=chrome?JSON.parse(chrome[1]):[];
  report.nativeInsets=insets?JSON.parse(insets[1]):null;
  report.mascotLoops=mascotLoops?JSON.parse(mascotLoops[1]):[];
  report.mascotTouch=mascotTouch?JSON.parse(mascotTouch[1]):[];
  report.emergencyLocale=emergencyLocale?JSON.parse(emergencyLocale[1]):[];
  report.checks=match?JSON.parse(match[1]):[];
  report.checkCount=report.checks.length;
  report.passed=/INSTRUMENTATION_CODE:\s*-1\b/.test(output) && !/cleanupError|FAIL after|INSTRUMENTATION_FAILED/.test(output);
  report.cleanupVerified=report.checks.includes('cleanup leaves 10.0 and 9.0 storage untouched');
  report.haptics={bridgeDispatch:report.checks.includes('native haptic bridge accepts interaction cue'),physicalFeel:'not verified on emulator'};
  if(!report.passed)throw Error('Instrumentation did not complete successfully. See instrumentation.log for the real failure.');
} catch(error) {report.error=String(error.stack||error);process.exitCode=1;}
finally {report.finishedAt=new Date().toISOString();await writeFile(path.join(out,'acceptance.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,checks:report.checkCount||0,report:path.join(out,'acceptance.json'),error:report.error||null}));}

