import {readFile,writeFile,cp,readdir,mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {createHash} from 'node:crypto';
const android=path.resolve(import.meta.dirname,'..');
const root=path.dirname(android);
const original=path.dirname(root);
const source=path.join(root,'v11-demo');
const baseline=path.join(original,'v11-demo');
const web=path.join(android,'app/src/main/assets/web');
const nativeOriginal=path.join(original,'Drama Alarm Android 11.0/app/src/main/assets/web');
const hash=value=>createHash('sha256').update(value).digest('hex');
const merged=spawnSync('git',['merge-file','-p',path.join(source,'app.js'),path.join(baseline,'app.js'),path.join(nativeOriginal,'app.js')],{encoding:'utf8'});
let app=merged.stdout;
const resolutions=[];
app=app.replace(/^<<<<<<<[^\n]*\n([\s\S]*?)^=======\n([\s\S]*?)^>>>>>>>[^\n]*\n/gm,(conflict,ours,theirs)=>{
 if(ours.includes('diagnostics()')&&theirs.includes('android:window.DramaAndroidHost')){
  resolutions.push('preserve compliance version and add native diagnostic permission status');
  return ours.replace('language:this.state.language,','language:this.state.language,android:window.DramaAndroidHost?.getStatus(),');
 }
 if(ours.includes('localStorage.setItem("drama-alarm-v11-compliance"')&&theirs.includes('window.DramaAndroidHost?.syncState(saved)')){
  resolutions.push('retain compliance storage key and native schedule mirror on save');
  return ours.replace(/(localStorage\.setItem\("drama-alarm-v11-compliance", JSON\.stringify\(saved\)\);)/,'$1\n        const nativeResult = window.DramaAndroidHost?.syncState(saved);\n        this.state.androidScheduleError = nativeResult?.error || "";');
 }
 return conflict;
});
if(merged.status===null||merged.status<0||merged.status>=128||/^<<<<<<<|^=======|^>>>>>>>/m.test(app)){
 await mkdir(path.join(root,'artifacts'),{recursive:true});
 await writeFile(path.join(root,'artifacts/android-web-merge-review.txt'),app||merged.stderr);
 throw Error('Review Android native-hook merge before replacing packaged files');
}
for(const hook of ['acceptNativeAlarm(event)','handleAndroidBack()','window.DramaAndroidHost?.syncState(saved)','window.DramaAndroidHost?.ready()'])if(!app.includes(hook))throw Error('Missing native hook '+hook);
for(const name of await readdir(source)){
 if(['app.js','index.html','audio.js','offline.js','sw.js','android.js','android-ui.js','android.css'].includes(name))continue;
 await cp(path.join(source,name),path.join(web,name),{recursive:true});
}
await writeFile(path.join(web,'app.js'),app);
let html=await readFile(path.join(source,'index.html'),'utf8');
html=html.replace('</head>','  <link rel="stylesheet" href="android.css">\n</head>')
 .replace('<script src="app.js"></script>','<script src="android.js"></script>\n  <script src="android-ui.js"></script>\n  <script src="app.js"></script>')
 .replace('<script src="offline.js"></script>','')
 .replace(/<body(?:\s+class="([^"]*)")?>/,(_,classes)=>`<body class="${classes?classes+' ':''}android-app-body">`);
await writeFile(path.join(web,'index.html'),html);
let audio=await readFile(path.join(source,'audio.js'),'utf8');
const guard='if (!this.context && navigator.userActivation && !navigator.userActivation.hasBeenActive)';
if(!audio.includes(guard))throw Error('Review native audio gesture guard');
audio=audio.replace(guard,'if (!window.DramaAndroidHost?.available && !this.context && navigator.userActivation && !navigator.userActivation.hasBeenActive)');
await writeFile(path.join(web,'audio.js'),audio);
for(const name of ['liquid-glass.js','liquid-glass.css','v7.css'])if(hash(await readFile(path.join(source,name)))!==hash(await readFile(path.join(web,name))))throw Error('Protected design source changed '+name);
const catalog=JSON.parse(await readFile(path.join(web,'assets/audio/catalog.json'),'utf8'));
if(catalog.items.length!==12)throw Error('Expected all twelve music files');
for(const item of catalog.items)if(hash(await readFile(path.join(source,item.src)))!==hash(await readFile(path.join(web,item.src))))throw Error('Changed music '+item.id);
const report={version:'11.0.0-compliance',method:'three-way merge against original 11.0 web and Android, retaining native scheduling/lifecycle hooks',resolutions,appSha256:hash(app),sourceAppSha256:hash(await readFile(path.join(source,'app.js'))),musicCount:12,musicBytesPreserved:true,protectedVisualSourcesPreserved:true,syncedAt:new Date().toISOString()};
await writeFile(path.join(root,'artifacts/android-web-sync.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
