import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import vm from 'node:vm';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const challengeSource=await readFile(`${root}/app/src/main/assets/web/challenges.js`,'utf8');
const appSource=await readFile(`${root}/app/src/main/assets/web/app.js`,'utf8');
const dataSource=await readFile(`${root}/app/src/main/assets/web/data.js`,'utf8');
const runtimeSource=await readFile(`${root}/app/src/main/assets/web/runtime.js`,'utf8');
const bankSource=await readFile(`${root}/app/src/main/assets/web/question-bank.js`,'utf8');
const context=vm.createContext({window:{},Math,Date,JSON,Intl,crypto:{randomUUID:()=>`id-${Math.random()}`},navigator:{platform:'unit-test',onLine:true},setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,clearInterval:()=>{},document:{getElementById:()=>null,querySelector:()=>null,querySelectorAll:()=>[]},history:{replaceState(){},pushState(){}},location:{},Notification:undefined});
// 11.0 resolves a topic against the installed catalog. Load the real bank before
// exercising Challenges, rather than a getPack()=>null fixture that turns every
// knowledge topic into "everyday". Keep a stable facade because app.js captures
// the bank once; each app fixture receives its own genuine storage-backed store.
vm.runInContext(bankSource,context,{filename:'question-bank.js'});
const bankFactory=context.window.DramaAlarmQuestionBank.createStore;
let fixtureBank=bankFactory({storage:null});
const bankFacade=Object.fromEntries(['getQuestion','listPacks','getPack','getStatus','sample','resetCache','setAccessResolver','canUse','questions','pick','prepare','getCatalog','getTutorial'].map(method=>[method,(...args)=>fixtureBank[method](...args)]));
context.window.DramaAlarmQuestionBank=bankFacade;
vm.runInContext(challengeSource,context);
const C=context.window.DramaAlarmChallenges;
const plain=v=>JSON.parse(JSON.stringify(v));
const sourceQuestion={id:'GEO001',question:'Which ocean is largest by surface area?',options:['Atlantic','Pacific','Indian','Arctic'],answer:1,level:'Gentle',contentVersion:'8.0.0',topic:'geography'};
const pick=()=>sourceQuestion;
const reports=[];
function test(name,fn){try{fn();reports.push({name,passed:true});}catch(error){reports.push({name,passed:false,error:error.stack});}}

test('11.0 harness uses the real ten-pack catalog and all 210 bundled questions',()=>{
 const packs=bankFacade.listPacks();assert.equal(packs.length,10);assert.equal(packs.reduce((sum,pack)=>sum+pack.questionCount,0),210);
 for(const id of ['everyday','geography','history']){assert.equal(bankFacade.getPack(id).available,true);assert.equal(bankFacade.canUse(id),true);assert.equal(C.topicOf(id),id);}
 assert.equal(bankFacade.canUse('europe'),false);assert.equal(bankFacade.getQuestion('europe'),null);
});

test('all three strengths and three topics have exact task counts',()=>{
 for(const [level,count]of [['Gentle',1],['Classic',2],['Diva',3]])for(const topic of ['everyday','geography','history']){
  const p=C.create({difficulty:level,questionTopic:topic},{pick,random:()=>.2,id:`${level}-${topic}`});
  assert.equal(p.total,count);assert.equal(p.completed,0);
  assert.equal(p.questions.filter(q=>q.kind==='choice').length,topic==='everyday' && level!=='Diva'?0:1);
  assert.equal(C.current(p),p.questions[0]);
 }
});
test('Classic everyday includes an integer multiplication or division',()=>{
 for(let n=0;n<300;n++){
  const p=C.create({difficulty:'Classic',questionTopic:'everyday'});
  assert.ok(['×','÷'].includes(p.questions[1].op));
 }
});
test('generated arithmetic has correct answers and no negative/fractional results',()=>{
 for(const level of C.levels)for(let i=0;i<4000;i++){
  const q=C.math(level,{multiplyDivide:i%2===0});
  const actual=q.op==='+'?q.a+q.b:q.op==='−'?q.a-q.b:q.op==='×'?q.a*q.b:q.a/q.b;
  assert.equal(q.answer,actual);assert.ok(Number.isInteger(actual)&&actual>=0);
  if(q.op==='÷'){assert.ok(q.b>0);assert.ok(q.a%q.b===0);}
  if(level==='Gentle')assert.ok(q.op==='+' || q.op==='−');
 }
});
test('correct answers complete exactly one, two or three required questions',()=>{
 for(const difficulty of C.levels){const p=C.create({difficulty,questionTopic:'everyday'},{pick});let answers=0;
  while(C.current(p)){const q=C.current(p);const result=C.grade(p,q.answer,q.id);assert.ok(result.correct);answers++;}
  assert.equal(answers,C.counts[difficulty]);assert.equal(p.completed,p.total);assert.equal(C.current(p),null);
  assert.equal(C.grade(p,0,'stale').accepted,false);
 }
});
test('wrong answers never clear previously completed progress or add questions',()=>{
 const p=C.create({difficulty:'Diva',questionTopic:'everyday'},{pick});
 C.grade(p,C.current(p).answer,C.current(p).id);assert.equal(p.completed,1);
 const beforeTotal=p.total;let result;
 for(let i=0;i<3;i++){const q=C.current(p);result=C.grade(p,q.answer+1,q.id);assert.equal(p.completed,1);assert.equal(p.total,beforeTotal);}
 assert.equal(result.downgraded,true);assert.equal(p.currentLevel,'Classic');assert.equal(p.difficulty,'Diva');
 assert.equal(C.current(p).kind,'math');assert.ok(['+','−'].includes(C.current(p).op));
});
test('a knowledge fallback still requires the remaining correct answer',()=>{
 const p=C.create({difficulty:'Gentle',questionTopic:'geography'},{pick});
 assert.equal(C.current(p).kind,'choice');C.replaceWithMath(p);
 assert.equal(p.total,1);assert.equal(p.completed,0);assert.equal(C.current(p).kind,'math');
 const q=C.current(p);assert.equal(C.grade(p,q.answer+1,q.id).complete,false);
 assert.equal(C.grade(p,q.answer,q.id).complete,true);
});
test('repeated lowering also changes future knowledge slots, not only current arithmetic',()=>{
 const p=C.create({difficulty:'Diva',questionTopic:'history'},{pick});
 for(let attempt=0;attempt<6;attempt++){const q=C.current(p);C.grade(p,q.answer+1,q.id);}
 assert.equal(p.currentLevel,'Gentle');assert.equal(p.completed,0);assert.equal(p.total,3);
 assert.ok(p.questions.every(q=>q.kind==='math' && q.level==='Gentle'));
});
test('three wrong choice answers switch only the remaining question to basic arithmetic',()=>{
 const p=C.create({difficulty:'Diva',questionTopic:'geography'},{pick,random:()=>.3});
 for(let i=0;i<2;i++){const q=C.current(p);C.grade(p,q.answer,q.id);}
 for(let i=0;i<3;i++){const q=C.current(p);C.grade(p,(q.answer+1)%4,q.id);}
 assert.equal(p.completed,2);assert.equal(p.total,3);assert.equal(C.current(p).kind,'math');assert.equal(C.current(p).level,'Gentle');
});
test('content unavailable falls back locally without changing the required count',()=>{
 for(const difficulty of C.levels){const p=C.create({difficulty,questionTopic:'history'},{pick:()=>null});assert.equal(p.total,C.counts[difficulty]);assert.ok(p.questions.every(q=>q.kind==='math'));assert.ok(p.fallbackReason);}
});
test('persisted task snapshots retain current question and stable answer option IDs',()=>{
 const p=C.create({difficulty:'Classic',questionTopic:'geography'},{pick});
 C.grade(p,C.current(p).answer,C.current(p).id);const before=plain(C.current(p));const restored=plain(p);
 assert.deepEqual(plain(C.current(restored)),before);assert.equal(C.grade(restored,before.answer,before.id).complete,true);
});
test('stale question submissions cannot credit a different question',()=>{
 const p=C.create({difficulty:'Classic',questionTopic:'everyday'});const q=C.current(p);C.grade(p,q.answer,q.id);
 assert.equal(C.grade(p,q.answer,q.id).accepted,false);assert.equal(p.completed,1);
});
test('legacy description preserves optional two-act structure until explicit apply',()=>{
 assert.equal(C.describe({difficulty:'Gentle',riddle:true}).total,2);
 assert.equal(C.describe({difficulty:'Diva',riddle:false,taskPlanVersion:7}).total,1);
 assert.equal(C.describe({difficulty:'Gentle',riddle:true,taskPlanVersion:8}).total,1);
 assert.equal(C.describe({difficulty:'Diva',riddle:true,taskPlanVersion:8}).total,3);
});

vm.runInContext(dataSource,context);vm.runInContext(runtimeSource,context);
vm.runInContext(appSource.replace('window.dramaAlarmApp = new DramaAlarmApp();','window.TestDramaAlarmApp = DramaAlarmApp;'),context);
function appFor(records={}){
 const storage=new Map(Object.entries(records));context.localStorage={getItem:key=>storage.get(key)||null,setItem:(key,val)=>storage.set(key,val),removeItem:key=>storage.delete(key)};
 fixtureBank=bankFactory({storage:context.localStorage});
 const app=Object.create(context.window.TestDramaAlarmApp.prototype);
 app.fast=true;app.soundEngine={cue:()=>{},getStatus:()=>({engineReady:true})};app.state=app.initialState();
 fixtureBank.setAccessResolver(id=>app.hasProduct(`pack:${id}`));
 app.render=()=>{};app.go=screen=>{app.state.screen=screen;app.save();};app.stopRinging=()=>{};app.startRinging=()=>{};app.setRingIntensity=()=>{};app.vibrate=()=>{};app.toast=()=>{};app.stopPreview=()=>{};app.closeModal=()=>{};app.cancelHold=()=>{};
 return {app,storage};
}
test('v7 migration leaves old storage byte-identical and preserves legacy alarms',()=>{
 const old=JSON.stringify({schemaVersion:7,onboarded:true,alarms:[{id:'legacy',label:'Old',time:'07:30',days:[1],difficulty:'Diva',riddle:true}],defaults:{difficulty:'Classic'}});
 const {app,storage}=appFor({'drama-alarm-v7':old});assert.equal(app.state.alarm.taskPlanVersion,7);assert.equal(app.state.defaults.taskPlanVersion,8);app.save();assert.equal(storage.get('drama-alarm-v7'),old);assert.equal(JSON.parse(storage.get('drama-alarm-v11-compliance')).schemaVersion,11);
 app.beginNewAlarm();assert.equal(app.state.alarm.taskPlanVersion,8);
});
test('11.0 migrates 10.0 read-only and keeps the original record byte-identical',()=>{
 const old=JSON.stringify({schemaVersion:10,onboarded:true,themeId:'velvet',language:'en',alarms:[{id:'ten-alarm',label:'Kept from 10.0',time:'07:30',days:[1],difficulty:'Classic',taskPlanVersion:8,soundId:'morning-dew'}]});
 const {app,storage}=appFor({'drama-alarm-v10':old});
 assert.equal(app.state.alarms[0].id,'ten-alarm');assert.equal(app.state.alarms[0].soundId,'morning-dew');assert.equal(app.state.themeId,'velvet');app.save();
 assert.equal(storage.get('drama-alarm-v10'),old);assert.equal(JSON.parse(storage.get('drama-alarm-v11-compliance')).schemaVersion,11);
});
test('11.0 app executes each strength end-to-end with real session state and no rehearsal results',()=>{
 for(const level of C.levels){const {app}=appFor();app.state.alarm=app.defaultAlarm({difficulty:level});app.resetChallenge('test');app.routeCurrentChallenge();
  let completed=0;while(app.state.activeSession){const q=C.current(app.state.challengePlan);assert.ok(q);if(q.kind==='math'){app.state.math.input=String(q.answer);app.submitMath();}else app.answerRiddle(q.answer);completed++;assert.ok(completed<=3);}
  assert.equal(completed,C.counts[level]);assert.equal(app.state.screen,'07');assert.equal(app.state.lastResult.totalQuestions,completed);assert.equal(app.state.history.length,0);assert.equal(app.state.wakeChecks.length,0);
 }
});
test('real completion saves the wake check immediately and once, independently of bow action',()=>{
 const {app}=appFor();app.state.alarm=app.defaultAlarm({difficulty:'Gentle'});app.state.alarms=[plain(app.state.alarm)];app.resetChallenge('alarm');app.routeCurrentChallenge();app.state.math.input=String(app.state.math.answer);app.submitMath();
 assert.equal(app.state.history.length,1);assert.equal(app.state.wakeChecks.length,1);assert.equal(app.state.activeSession,null);assert.equal(app.state.screen,'07');
});
test('Settings defaults and editor drafts never silently rewrite existing alarms',()=>{
 const {app}=appFor();const existing=app.defaultAlarm({id:'existing',difficulty:'Gentle'});app.state.alarms=[plain(existing)];
 app.state.alarm=plain(app.state.defaults);app.setChallengeDifficulty('Diva');assert.equal(app.state.defaults.difficulty,'Diva');assert.equal(app.state.alarms[0].difficulty,'Gentle');
 app.beginEditAlarm('existing');app.setChallengeDifficulty('Classic');app.selectQuestionTopic('history');assert.equal(app.state.alarm.difficulty,'Classic');assert.equal(app.state.alarms[0].difficulty,'Gentle');assert.equal(app.state.alarms[0].questionTopic,'everyday');
 app.cancelEditor();assert.equal(app.state.alarms[0].difficulty,'Gentle');assert.equal(app.state.alarms[0].questionTopic,'everyday');assert.equal(app.state.defaults.difficulty,'Diva');
});
test('app three-wrong safety route retains completed progress and still requires the final correct answer',()=>{
 const {app}=appFor();app.state.alarm=app.defaultAlarm({difficulty:'Classic',questionTopic:'geography'});app.resetChallenge('test');app.routeCurrentChallenge();app.state.math.input=String(app.state.math.answer);app.submitMath();
 for(let attempt=0;attempt<3;attempt++){const q=C.current(app.state.challengePlan);app.answerRiddle((q.answer+1)%4);if(attempt<2)app.nextRiddle();}
 assert.equal(app.state.screen,'21');assert.equal(app.state.safetyKind,'v8-auto');assert.equal(app.state.challengePlan.completed,1);assert.equal(app.state.challengePlan.total,2);assert.ok(app.state.activeSession);assert.equal(app.state.lastResult,null);
 app.continueSafety();assert.equal(app.state.screen,'04');app.state.math.input=String(app.state.math.answer);app.submitMath();assert.equal(app.state.screen,'07');assert.equal(app.state.lastResult.correctQuestions,2);
});
test('Wake-up Check is exactly one basic question and does not create another challenge result',()=>{
 const {app}=appFor();app.state.alarm=app.defaultAlarm({difficulty:'Diva',questionTopic:'history'});app.state.history=[{sessionId:'original'}];
 app.state.wakeChecks=[{id:'check-1',sessionId:'original',occurrenceId:'original-occurrence',status:'pending',dueAt:Date.now()-100,alarm:plain(app.state.alarm)}];
 app.checkWakeCheckDue();assert.equal(app.state.challengePlan,null);app.wakeTimeout();assert.equal(app.state.checkMode,true);assert.equal(app.state.math.level,'Gentle');assert.ok(['+','−'].includes(app.state.math.op));app.state.math.input=String(app.state.math.answer);app.submitMath();
 assert.equal(app.state.wakeChecks[0].status,'confirmed');assert.equal(app.state.history.length,1);assert.equal(app.state.wakeChecks.length,1);assert.equal(app.state.activeSession,null);
});
test('new sessions and saved choice order survive an app reload',()=>{
 const {app,storage}=appFor();app.state.alarm=app.defaultAlarm({difficulty:'Classic',questionTopic:'geography'});app.resetChallenge('test');app.routeCurrentChallenge();app.state.math.input=String(app.state.math.answer);app.submitMath();
 const before=plain(app.state.riddleInstance);app.save();const data=storage.get('drama-alarm-v11-compliance');const restored=appFor({'drama-alarm-v11-compliance':data}).app;
 assert.equal(restored.state.screen,'06');assert.equal(restored.state.challengePlan.completed,1);assert.deepEqual(plain(restored.state.riddleInstance),before);assert.equal(restored.state.challengePlan.total,2);
});
test('legacy active two-act snapshots are restored without creating a new plan',()=>{
 const old=JSON.stringify({schemaVersion:7,onboarded:true,alarms:[],activeSession:{id:'old-session',kind:'alarm',phase:'06',startedAt:Date.now(),alarm:{id:'a',difficulty:'Gentle',riddle:true},progress:{math:{a:8,b:7,op:'+',answer:15,input:'',wrong:0},riddleInstance:{...sourceQuestion},riddleWrong:1,riddleIndex:1}}});
 const {app,storage}=appFor({'drama-alarm-v7':old});assert.equal(app.state.screen,'06');assert.equal(app.state.challengePlan,null);assert.equal(ChallengesTotal(app.state.alarm),2);app.save();assert.equal(storage.get('drama-alarm-v7'),old);
});
test('single-alarm historical records do not inherit the new default task count',()=>{
 const old=JSON.stringify({onboarded:true,alarm:{id:'pre-v7',label:'Old alarm',time:'07:30',days:[1],difficulty:'Gentle',riddle:true}});
 const {app}=appFor({'drama-alarm-demo':old});assert.equal(app.state.alarms.length,1);assert.equal(app.state.alarms[0].taskPlanVersion,7);assert.equal(C.describe(app.state.alarms[0]).total,2);
});
test('changing a legacy topic requires explicit consent before changing its question count',()=>{
 const {app}=appFor();app.state.alarm=app.defaultAlarm({taskPlanVersion:7,difficulty:'Gentle',riddle:true});let prompted=false;
 app.confirmTopicMigration=topic=>{prompted=topic==='geography';};app.selectQuestionTopic('geography');assert.equal(prompted,true);assert.equal(app.state.alarm.taskPlanVersion,7);assert.equal(C.describe(app.state.alarm).total,2);
 app.selectQuestionTopic('geography',true);assert.equal(app.state.alarm.taskPlanVersion,8);assert.equal(C.describe(app.state.alarm).total,1);
});
test('historical sample and offline routes restore their owner pack and original editor scope',()=>{
 const {app}=appFor();app.beginNewAlarm();app.state.alarm.label='Draft kept';const id=app.state.alarm.id;
 app.openQuestionLibrary();assert.equal(app.state.libraryReturnScreen,'02');app.state.activePackId='history';app.state.screen='48';
 app.handle('question-pack-back',{dataset:{}});assert.equal(app.state.screen,'47');assert.equal(app.state.activePackId,'history');
 app.state.screen='49';app.handle('question-pack-back',{dataset:{}});assert.equal(app.state.screen,'47');
 app.handle('question-pack-back',{dataset:{}});assert.equal(app.state.screen,'46');app.handle('question-library-back',{dataset:{}});assert.equal(app.state.screen,'02');
 assert.equal(app.state.editorOpen,true);assert.equal(app.state.alarm.id,id);assert.equal(app.state.alarm.label,'Draft kept');assert.equal(app.state.alarms.length,0);
});
test('applying a pack from details returns to the original editor without saving the alarm',()=>{
 const {app}=appFor();app.state.defaults.difficulty='Classic';app.beginNewAlarm();app.state.alarm.label='Topic draft';const id=app.state.alarm.id;app.openQuestionLibrary();app.state.screen='47';
 app.selectQuestionTopic('geography');assert.equal(app.state.screen,'02');assert.equal(app.state.editorOpen,true);assert.equal(app.state.alarm.id,id);assert.equal(app.state.alarm.label,'Topic draft');assert.equal(app.state.alarm.questionTopic,'geography');assert.equal(C.describe(app.state.alarm).total,2);assert.equal(app.state.alarms.length,0);
});
test('legacy pack confirmation returns to its original draft and does not save the migration',()=>{
 const {app}=appFor();const old=app.defaultAlarm({id:'legacy-topic',taskPlanVersion:7,difficulty:'Gentle',riddle:true});app.state.alarms=[plain(old)];app.beginEditAlarm(old.id);app.openQuestionLibrary();app.state.screen='47';let prompted=false;app.confirmTopicMigration=()=>{prompted=true;};
 app.selectQuestionTopic('history');assert.equal(prompted,true);assert.equal(app.state.screen,'47');assert.equal(app.state.alarm.taskPlanVersion,7);
 app.selectQuestionTopic('history',true);assert.equal(app.state.screen,'02');assert.equal(app.state.editorOpen,true);assert.equal(app.state.alarm.questionTopic,'history');assert.equal(C.describe(app.state.alarm).total,1);assert.equal(app.state.alarms[0].taskPlanVersion,7);assert.equal(C.describe(app.state.alarms[0]).total,2);
});
test('pack apply in Settings changes only new defaults while ordinary topic selection stays on its page',()=>{
 const {app}=appFor();const old=app.defaultAlarm({id:'unchanged',taskPlanVersion:7,difficulty:'Diva',riddle:true});app.state.alarms=[plain(old)];app.state.alarm=plain(app.state.defaults);app.state.libraryReturnScreen='14';app.state.screen='47';app.selectQuestionTopic('history');
 assert.equal(app.state.screen,'14');assert.equal(app.state.defaults.questionTopic,'history');assert.equal(app.state.alarms[0].questionTopic,'everyday');assert.equal(app.state.alarms[0].taskPlanVersion,7);
 app.state.screen='26';app.selectQuestionTopic('geography');assert.equal(app.state.screen,'26');assert.equal(app.state.defaults.questionTopic,'geography');
});
test('editor errors focus the original field without scrolling the outer page or losing the draft',()=>{
 const {app}=appFor();app.beginNewAlarm();app.state.alarm.label='Draft stays';const oldDocument=context.document;let focusOptions;
 const field={tabIndex:-1,focus:options=>{focusOptions=options;},getBoundingClientRect:()=>({top:440,height:48})};
 const body={scrollTop:40,clientHeight:300,getBoundingClientRect:()=>({top:100,height:300})};
 context.document={getElementById:id=>id==='alarm-time'?field:null,querySelector:selector=>selector==='.screen-body'?body:null};
 try{assert.equal(app.editorFailure('Choose a future time.','alarm-time'),false);assert.equal(focusOptions.preventScroll,true);assert.equal(field.tabIndex,0);assert.equal(body.scrollTop,254);assert.equal(app.state.alarm.label,'Draft stays');assert.equal(app.state.editorOpen,true);}finally{context.document=oldDocument;}
});
function ChallengesTotal(alarm){return C.describe(alarm).total;}
test('11.0 reset removes only its own user data/cache and keeps historical records',()=>{
 const old=JSON.stringify({schemaVersion:7,onboarded:true,alarms:[]});const {app,storage}=appFor({'drama-alarm-v7':old,'drama-alarm-v11-compliance-question-cache':'cache'});
 app.render=()=>{};context.history={replaceState:()=>{}};context.location={href:'https://example.invalid/v11/'};app.confirmResetDemo();
 assert.equal(storage.get('drama-alarm-v7'),old);assert.equal(storage.has('drama-alarm-v11-compliance-question-cache'),false);assert.equal(JSON.parse(storage.get('drama-alarm-v11-compliance')).schemaVersion,11);assert.equal(app.state.onboarded,false);assert.equal(app.state.alarms.length,0);
});
const savedPrepare=bankFacade.prepare;
try {
 const bank=context.window.DramaAlarmQuestionBank;
 let finish;bank.prepare=()=>new Promise(resolve=>{finish=resolve;});
 const {app}=appFor();app.state.activePackId='geography';const pending=app.prepareQuestionPack();assert.equal(app.state.screen,'49');assert.equal(app.state.packPreparing,true);
 app.state.activePackId='history';app.updateDerivedState();assert.equal(app.state.packPreparing,false);assert.equal(app.state.activePack.id,'history');
 finish({ok:true});await pending;app.updateDerivedState();assert.equal(app.state.activePack.id,'history');assert.equal(app.state.packPreparing,false);
 reports.push({name:'async content update status remains owned by its requested pack after selection changes',passed:true});
}catch(error){reports.push({name:'async content update status remains owned by its requested pack after selection changes',passed:false,error:error.stack});}
finally{bankFacade.prepare=savedPrepare;}

let nativeStopCount=0;
context.window.DramaAndroidHost={syncState:()=>({}),getStatus:()=>({notifications:true,exactAlarms:true,fullScreenIntent:true}),stopRinging:()=>{nativeStopCount++;}};
test('Android delivery leaves guide replay before capturing the formal return route',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.screen='14';app.state.themeId='velvet';app.state.alarms=[app.defaultAlarm({id:'guide-interrupt'})];app.routeStack=['14'];app.routeScroll={};app.routeExpansion={};app.applyThemeToDocument=()=>{};
 app.beginOnboardingReplay();assert.equal(app.state.screen,'08');assert.ok(app.onboardingReplay);app.state.themeId='daybreak';
 app.acceptNativeAlarm({kind:'alarm',alarmId:'guide-interrupt',scheduledAt:Date.now()-500});
 assert.equal(app.onboardingReplay,null);assert.equal(app.state.onboardingReplay,false);assert.equal(app.state.themeId,'velvet');assert.equal(app.state.activeSession.kind,'alarm');assert.equal(app.state.activeSession.returnContext.screen,'14');
});
test('Android hardware Back exits guide start without retaining temporary preferences',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.screen='14';app.state.themeId='velvet';app.routeStack=['14'];app.routeScroll={};app.routeExpansion={};app.applyThemeToDocument=()=>{};
 app.beginOnboardingReplay();app.state.themeId='daybreak';assert.equal(app.handleAndroidBack(),true);
 assert.equal(app.onboardingReplay,null);assert.equal(app.state.screen,'14');assert.equal(app.state.themeId,'velvet');assert.equal(JSON.parse(context.localStorage.getItem('drama-alarm-v11-compliance')).themeId,'velvet');
});
test('Android and foreground dispatch create only one occurrence and one active session',()=>{
 const {app}=appFor();app.state.onboarded=true;const alarm=app.defaultAlarm({id:'android-native',time:'07:30'});app.state.alarms=[alarm];
 const at=Date.now()-500;const payload={kind:'alarm',id:`${alarm.id}@${at}`,alarmId:alarm.id,scheduledAt:at};
 app.acceptNativeAlarm(payload);const sessionId=app.state.activeSession.id;
 assert.equal(app.state.occurrences.length,1);assert.equal(app.state.activeSession.occurrenceId,payload.id);assert.equal(app.state.pendingQueue.length,0);
 app.acceptNativeAlarm(payload);assert.equal(app.state.occurrences.length,1);assert.equal(app.state.activeSession.id,sessionId);assert.equal(app.state.pendingQueue.length,0);
});
test('Android second alarm queues behind a formal active session',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.alarms=[app.defaultAlarm({id:'a'}),app.defaultAlarm({id:'b'})];const at=Date.now()-500;
 app.acceptNativeAlarm({kind:'alarm',alarmId:'a',scheduledAt:at});const sessionId=app.state.activeSession.id;
 app.acceptNativeAlarm({kind:'alarm',alarmId:'b',scheduledAt:at});assert.equal(app.state.activeSession.id,sessionId);assert.equal(app.state.pendingQueue.length,1);assert.equal(app.state.pendingQueue[0].alarm.id,'b');
});
test('Android late delivery over ten minutes is recorded missed without starting a challenge',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.alarms=[app.defaultAlarm({id:'late',repeatMode:'once'})];
 app.acceptNativeAlarm({kind:'alarm',alarmId:'late',scheduledAt:Date.now()-610000});assert.equal(app.state.activeSession,null);assert.equal(app.state.occurrences[0].status,'missed');assert.equal(app.state.alarms[0].enabled,false);
});
test('Android notification emergency records a safe stop without creating a completion or wake check',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.alarms=[app.defaultAlarm({id:'stopped',repeatMode:'once'})];const at=Date.now()-500;const event={kind:'emergency',id:`stopped@${at}`,alarmId:'stopped',scheduledAt:at};
 app.acceptNativeAlarm(event);assert.equal(app.state.occurrences[0].status,'emergency_stopped');assert.equal(app.state.alarms[0].enabled,false);assert.equal(app.state.activeSession,null);assert.equal(app.state.history.length,0);assert.equal(app.state.wakeChecks.length,0);
 app.acceptNativeAlarm({...event,kind:'alarm'});assert.equal(app.state.activeSession,null);assert.equal(app.state.history.length,0);
});
test('Android emergency delivery safely closes an already restored active challenge',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.alarms=[app.defaultAlarm({id:'active'})];const at=Date.now()-500;const event={kind:'alarm',alarmId:'active',id:`active@${at}`,scheduledAt:at};
 app.acceptNativeAlarm(event);assert.ok(app.state.activeSession);app.acceptNativeAlarm({...event,kind:'emergency'});assert.equal(app.state.activeSession,null);assert.equal(app.state.occurrences[0].status,'emergency_stopped');assert.equal(app.state.history.length,0);
});
test('Android check-expired delivery reaches the single Gentle follow-up, not a new formal result',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.wakeChecks=[{id:'android-check',sessionId:'old',occurrenceId:'old@1',status:'pending',dueAt:Date.now()-70000,alarm:app.defaultAlarm({id:'check-alarm'})}];
 app.acceptNativeAlarm({kind:'check-expired',id:'android-check',checkId:'android-check',scheduledAt:Date.now()-10000});assert.equal(app.state.screen,'04');assert.equal(app.state.checkMode,true);assert.equal(app.state.wakeChecks[0].status,'checking');assert.equal(app.state.history.length,0);assert.equal(app.state.math.level,'Gentle');
});
test('Android notification permission is read from the native bridge rather than a browser capability',()=>{
 const {app}=appFor();assert.equal(app.state.permission,true);assert.equal(app.state.permissionStatus,'granted');assert.equal(app.state.androidStatus.exactAlarms,true);
});
try {
 const {app}=appFor();const before=nativeStopCount;
 app.soundEngine={startRinging:async()=>false,getStatus:()=>({engineReady:false})};await context.window.TestDramaAlarmApp.prototype.startRinging.call(app);assert.equal(nativeStopCount,before);
 app.soundEngine={startRinging:async()=>true,getStatus:()=>({engineReady:true})};await context.window.TestDramaAlarmApp.prototype.startRinging.call(app);assert.equal(nativeStopCount,before+1);
 reports.push({name:'Android fallback sound stops only after WebAudio reports ready',passed:true});
}catch(error){reports.push({name:'Android fallback sound stops only after WebAudio reports ready',passed:false,error:error.stack});}


test('Android follow-up emergency preserves the completed main result and cancels the pending check',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.occurrences=[{id:'main@1',status:'challenge_completed'}];app.state.history=[{sessionId:'finished'}];app.state.wakeChecks=[{id:'check-main',occurrenceId:'main@1',status:'pending',dueAt:Date.now()-1000,alarm:app.defaultAlarm()}];
 app.acceptNativeAlarm({kind:'emergency',id:'check-main',checkId:'check-main',occurrenceId:'main@1'});assert.equal(app.state.wakeChecks[0].status,'cancelled');assert.equal(app.state.occurrences[0].status,'challenge_completed');assert.equal(app.state.history.length,1);assert.equal(app.state.activeSession,null);
});
test('Android follow-up emergency clears an active check without rewriting the original occurrence',()=>{
 const {app}=appFor();app.state.onboarded=true;app.state.occurrences=[{id:'main@2',status:'challenge_completed'}];app.state.wakeChecks=[{id:'check-active',occurrenceId:'main@2',status:'pending',dueAt:Date.now()-1000,alarm:app.defaultAlarm()}];app.checkWakeCheckDue();assert.ok(app.state.activeSession);
 app.acceptNativeAlarm({kind:'emergency',id:'check-active',checkId:'check-active',occurrenceId:'main@2'});assert.equal(app.state.wakeChecks[0].status,'cancelled');assert.equal(app.state.activeSession,null);assert.equal(app.state.activeCheckId,null);assert.equal(app.state.occurrences[0].status,'challenge_completed');
});

// Execute the real audio adapter without a DOM. The mock supplies the WebAudio
// graph only; actual gesture policy and AudioContext state checks remain in
// audio.js so a host configuration cannot claim playback that never started.
const audioSource = await readFile(`${root}/app/src/main/assets/web/audio.js`, 'utf8');
function audioPolicyFixture({android = false, activated = false, audioState = 'running'} = {}) {
 let constructed = 0, resumed = 0;
 class MockAudioContext {
  constructor() { constructed++; this.state = audioState; this.destination = {}; }
  addEventListener() {}
  createGain() { return {gain:{value:0},connect(){return this;}}; }
  createDynamicsCompressor() { return {threshold:{},knee:{},ratio:{},attack:{},release:{},connect(){return this;}}; }
  async resume() { resumed++; }
 }
 const audioWindow = {AudioContext:MockAudioContext};
 if (android) audioWindow.DramaAndroidHost = {available:true};
 const sandbox = vm.createContext({window:audioWindow,navigator:{userActivation:{hasBeenActive:activated}},setTimeout:()=>1,clearTimeout:()=>{}});
 vm.runInContext(audioSource,sandbox,{filename:'audio.js'});
 return {engine:new audioWindow.DramaAlarmAudio([]),counts:()=>({constructed,resumed})};
}
for (const [name,options,expected,expectedConstructed] of [
 ['Browser audio still requires the first user gesture',{android:false,activated:false},false,0],
 ['Trusted Android alarm can initialize WebAudio without a prior touch',{android:true,activated:false},true,1],
 ['Android playback remains blocked when the AudioContext does not become running',{android:true,activated:false,audioState:'suspended'},false,1],
 ['Ordinary browser playback remains available after a user gesture',{android:false,activated:true},true,1],
]) {
 try {
  const fixture=audioPolicyFixture(options);
  assert.equal(await fixture.engine.unlock(),expected);
  assert.equal(fixture.counts().constructed,expectedConstructed);
  assert.equal(fixture.engine.getStatus().engineReady,expected);
  if (options.audioState === 'suspended') {
   assert.equal(fixture.counts().resumed,1);
   assert.equal(fixture.engine.getStatus().lastError,'playback-needs-attention');
  }
  if (!options.android && !options.activated) assert.equal(fixture.engine.getStatus().lastError,'user-gesture-required');
  reports.push({name,passed:true});
 } catch(error) {reports.push({name,passed:false,error:error.stack});}
}

const adapterSource=await readFile(`${root}/app/src/main/assets/web/android.js`,'utf8');
test('Android haptic adapter maps answer, celebration and wheel semantics to native effects',()=>{
 const cues=[];const sandbox=vm.createContext({window:{DramaAndroid:{getStatus:()=>({}),haptic:cue=>cues.push(cue)}},document:{documentElement:{classList:{add(){}}},addEventListener(){}},setInterval:()=>1});
 vm.runInContext(adapterSource,sandbox,{filename:'android.js'});const host=sandbox.window.DramaAndroidHost;
 for(const [pattern,cue] of [[[35,45,70],'bravo'],[[30],'answer'],[[50,40,50],'answer'],[8,'interaction'],[12,'interaction'],[12,'selection'],[12,'unknown']])assert.equal(host.haptic(pattern,cue),true);
 assert.deepEqual(cues,['success','success','error','tick','click','selection','click']);
 sandbox.window.DramaAndroid.haptic=()=>{throw Error('device unavailable');};assert.equal(host.haptic(12,'interaction'),false);
});
test('Android chrome adapter follows launch, effective preview, dark scenes and rollback',()=>{
 const calls=[];let launch=false,dark=false,launched=true,reduced=false;
 const app={state:{themeId:'daybreak',themePreviewId:null,reduceMotion:false,activeSession:null}};
 const doc={documentElement:{classList:{add(){}},dataset:{theme:'daybreak'}},body:{classList:{contains:()=>launched}},addEventListener(){},querySelector:selector=>selector==='.launch-stage'?launch:selector==='#app .screen--dark'?dark:null};
 const sandbox=vm.createContext({window:{dramaAlarmApp:app,matchMedia:()=>({matches:reduced}),DramaAndroid:{getStatus:()=>({}),updateChrome:(theme,mode)=>calls.push([theme,mode])}},document:doc,setInterval:()=>1});
 vm.runInContext(adapterSource,sandbox,{filename:'android.js'});const host=sandbox.window.DramaAndroidHost;
 host.syncChrome(true);assert.deepEqual(calls.at(-1),['daybreak','content']);
 app.state.themePreviewId='velvet';doc.documentElement.dataset.theme='velvet';host.syncChrome(true);assert.deepEqual(calls.at(-1),['velvet','content']);
 app.state.themePreviewId=null;doc.documentElement.dataset.theme='daybreak';host.syncChrome(true);assert.deepEqual(calls.at(-1),['daybreak','content']);
 dark=true;host.syncChrome(true);assert.deepEqual(calls.at(-1),['daybreak','dark']);
 dark=false;launch=true;launched=false;host.syncChrome(true);assert.deepEqual(calls.at(-1),['daybreak','launch']);
 reduced=true;host.syncChrome(true);assert.deepEqual(calls.at(-1),['daybreak','content']);
});

const failed=reports.filter(item=>!item.passed);
const adaptations=[
 'Load the actual 11.0 question bank before challenge tests, because topic validation now consults installed catalog metadata.',
 'Replace null getPack metadata with the genuine ten-pack/210-question store and recreate its storage binding per app fixture.',
 'Keep the application-captured bank facade stable and restore the isolated asynchronous prepare stub after its test.',
 'Retain native duplicate dispatch, audio handoff, emergency safety and permission checks. Storage assertions use the independent compliance namespace.',
 'Rename version labels and isolate output under Android11/artifacts/v11. Historical sample-route recovery remains tested without restoring a public question-preview feature.',
 'Keep DOM/native doubles explicit for chrome events; verify preview rollback, native guide preemption and read-only 10.0 migration independently.'
];
await mkdir(`${root}/artifacts/v11`,{recursive:true});
await writeFile(`${root}/artifacts/v11/web-core-tests.json`,JSON.stringify({version:'11.0.0-compliance',scope:'Real Android-host web logic with VM-based native, DOM, timer and audio doubles; not physical-device verification.',adaptations,tests:reports.length,passed:reports.length-failed.length,failed:failed.length,testsDetail:reports},null,2)+'\n');
for(const item of reports)console.log(`${item.passed?'PASS':'FAIL'} ${item.name}${item.error?'\n'+item.error:''}`);
assert.equal(failed.length,0,`${failed.length} core tests failed`);
