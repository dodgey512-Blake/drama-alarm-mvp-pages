package com.dramaalert.android;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.SystemClock;
import android.webkit.WebView;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/** Device-side acceptance checks. No browser driver or test framework dependency. */
public final class SmokeInstrumentation extends Instrumentation {
    private MainActivity activity;
    private WebView web;
    private final List<String> passed = new ArrayList<>();
    private String originalStorage;
    private String originalV9Storage;
    private String originalV10Storage;
    private boolean storageSnapshotTaken;
    private Map<String, ?> originalNative;
    private SharedPreferences preferences;
    private Context target;

    @Override public void onCreate(Bundle arguments) { super.onCreate(arguments); start(); }

    @Override public void onStart() {
        new Thread(() -> {
            Bundle result = new Bundle();
            int resultCode = Activity.RESULT_OK;
            try {
                target = getTargetContext();
                preferences = target.getSharedPreferences(AlarmScheduler.PREFS, Context.MODE_PRIVATE);
                originalNative = new HashMap<>(preferences.getAll());
                launch();
                originalStorage = (String) evaluate("localStorage.getItem('drama-alarm-v11-compliance')");
                originalV9Storage = (String) evaluate("localStorage.getItem('drama-alarm-v9')");
                originalV10Storage = (String) evaluate("localStorage.getItem('drama-alarm-v10')");
                storageSnapshotTaken = true;
                check("offline local origin", "https://appassets.androidplatform.net/assets/web/index.html".equals(evaluate("location.href")));
                check("Android bridge available", Boolean.TRUE.equals(evaluate("window.DramaAndroidHost.available")));
                check("native haptic bridge accepts interaction cue", Boolean.TRUE.equals(evaluate("DramaAndroidHost.haptic(12,'interaction')===true")));
                check("local 210-question catalog", ((Number) evaluate("window.DramaAlarmQuestionBank.getCatalog().actualFixedQuestionCount")).intValue() == 210);
                verifyComplianceNative();
                verifyBundledMusic(result);
                verifyMascotLoops(result);
                verifyThemeChrome(result);
                verifyEmergencyLocale(result);
                check("initial screen in actual WebView", Boolean.TRUE.equals(evaluate("!!document.querySelector('#app .screen')")));
                // Exercise the visible first-use CTA, not a hidden scene jump.
                // Isolate the fixture state and suppress only browser-history
                // writes; real routing, rendering and the native save bridge run.
                JSONObject onboarding = new JSONObject((String)evaluate("JSON.stringify((()=>{const a=dramaAlarmApp,state=a.state,go=a.go,stack=a.routeStack,scroll=a.routeScroll,expansion=a.routeExpansion;try{a.state={...state,onboarded:false,themeOnboardingComplete:false,intensityOnboardingComplete:false,adFreeOnboardingSeen:false,themeId:'daybreak',pendingThemeId:'daybreak',themePreviewId:null,screen:'08',alarms:[],activeSession:null,alarm:a.defaultAlarm()};a.routeStack=['08'];a.routeScroll={};a.routeExpansion={};a.go=function(screen,options){return go.call(this,screen,{...options,history:false});};a.render();const cta=document.querySelector('[data-action=quick-create-alarm]');if(!cta)return {path:[],visibleCTA:false};cta.click();const path=[a.state.screen];a.handle('confirm-theme',{dataset:{}});path.push(a.state.screen);a.handle('finish-intensity-onboarding',{dataset:{}});path.push(a.state.screen);a.handle('continue-free',{dataset:{}});path.push(a.state.screen);return {path,visibleCTA:true,editorOpen:a.state.editorOpen,adFreeOwned:a.hasProduct('ad-free')};}finally{a.state=state;a.go=go;a.routeStack=stack;a.routeScroll=scroll;a.routeExpansion=expansion;a.render();a.save();}})())"));
                check("first-use visible CTA follows theme, intensity, optional ad-free and editor", "[\"37\",\"45\",\"52\",\"02\"]".equals(onboarding.getJSONArray("path").toString()) && onboarding.optBoolean("visibleCTA") && onboarding.optBoolean("editorOpen") && !onboarding.optBoolean("adFreeOwned"), onboarding.toString());

                // Render all 53 routes in four approved themes without initiating
                // alarm/timer side effects. This exercises the actual WebView DOM.
                JSONArray routes = new JSONArray((String)evaluate("JSON.stringify(Object.keys(DramaAlarmShellRegistry))"));
                String priorScreen = (String)evaluate("dramaAlarmApp.state.screen");
                int renderedCount = 0;
                int previewGeometryCount = 0;
                int cardGeometryCount = 0;
                JSONArray themeGeometry = new JSONArray();
                // Yield to Chromium between pages. One 212-render JavaScript task
                // starves WebView's frame pipeline and does not represent real use.
                for (String theme : new String[]{"daybreak","velvet","lunar","amber"}) {
                    for (int index=0;index<routes.length();index++) {
                        String id=routes.getString(index);
                        Object rendered=evaluate("(()=>{const a=dramaAlarmApp;a.state.themeId="+JSONObject.quote(theme)+";a.state.pendingThemeId="+JSONObject.quote(theme)+";a.state.themePreviewId=null;a.state.screen="+JSONObject.quote(id)+";a.render();return !!document.querySelector('#app .screen');})()");
                        if (!Boolean.TRUE.equals(rendered)) throw new AssertionError("Route failed: "+theme+"/"+id);
                        if("39".equals(id)) {
                            JSONObject box = new JSONObject((String)evaluate("JSON.stringify((()=>{const art=document.querySelector('#app>.screen .v10-theme-preview-hero .theme-choice-art'),r=art?.getBoundingClientRect();return {width:r?.width||0,height:r?.height||0,viewport:innerWidth};})())"));
                            box.put("theme",theme).put("route",id);themeGeometry.put(box);
                            if(box.getDouble("width")<250 || Math.abs(box.getDouble("height")-270)>2)throw new AssertionError("Theme preview must fill hero, not legacy 76px strip: "+box);
                            previewGeometryCount++;
                        }
                        if("38".equals(id)) {
                            JSONObject geometry = new JSONObject((String)evaluate("JSON.stringify((()=>{const items=[...document.querySelectorAll('#app>.screen .v10-theme-select .theme-choice-art')].map(art=>{const r=art.getBoundingClientRect(),p=art.parentElement.getBoundingClientRect();return {width:r.width,height:r.height,parent:p.width};});return {items,valid:items.length===4&&items.every(r=>r.width>100&&Math.abs(r.width-r.parent)<2&&Math.abs(r.height-150)<2)};})())"));
                            geometry.put("theme",theme).put("route",id);themeGeometry.put(geometry);
                            if(!geometry.getBoolean("valid"))throw new AssertionError("Theme thumbnail must fill its card: "+geometry);
                            cardGeometryCount++;
                        }
                        renderedCount++;
                    }
                }
                evaluate("dramaAlarmApp.state.screen="+JSONObject.quote(priorScreen)+";dramaAlarmApp.render();true");
                check("53 routes in four themes", routes.length()>=53 && renderedCount==routes.length()*4);
                check("four theme preview heroes have full-width 270px artwork", previewGeometryCount==4);
                check("all theme thumbnails fill their cards at 150px height", cardGeometryCount==4);
                result.putString("layoutMetrics",themeGeometry.toString());
                check("Chinese locale can be selected", Boolean.TRUE.equals(evaluate("(()=>{const a=dramaAlarmApp;a.handle('set-language',{dataset:{locale:'zh-CN'}});a.go('14');return a.state.language==='zh-CN' && document.querySelector('#app').innerText.includes('设置');})()")));
                check("English locale and native mirror update", Boolean.TRUE.equals(evaluate("(()=>{const a=dramaAlarmApp;a.handle('set-language',{dataset:{locale:'en'}});a.go('14');return a.state.language==='en' && document.querySelector('#app').innerText.includes('Settings');})()")) && "en".equals(preferences.getString("language","")));
                evaluate("dramaAlarmApp.handle('set-language',{dataset:{locale:'zh-CN'}});true");
                check("fake device chrome removed", Boolean.TRUE.equals(evaluate("[...document.querySelectorAll('.status-bar')].every(e=>getComputedStyle(e).display==='none')")));
                check("viewport follows Android WebView", Boolean.TRUE.equals(evaluate("Math.abs(document.querySelector('.phone').getBoundingClientRect().width-innerWidth)<2 && Math.abs(document.querySelector('.phone').getBoundingClientRect().height-innerHeight)<2")));

                check("persistence fixture saved", Boolean.TRUE.equals(evaluate("(()=>{const a=dramaAlarmApp;a.state.activeSession=null;a.state.alarms=[];a.state.wakeChecks=[];a.state.pendingQueue=[];a.state.onboarded=true;a.state.themeId='velvet';a.state.screen='01';return a.save();})()")));
                reloadAndAwait();
                check("saved theme survives WebView recreation", "velvet".equals(evaluate("dramaAlarmApp.state.themeId")));
                check("saved theme restores native system surfaces",until(()->"velvet".equals(new JSONObject((String)evaluate("JSON.stringify(DramaAndroidHost.getChromeStatus())")).optString("theme")),5_000));
                check("saved onboarding survives WebView recreation", Boolean.TRUE.equals(evaluate("dramaAlarmApp.state.onboarded")));

                // Use a real future configuration through the JS save bridge,
                // then read the native scheduler's durable registrations.
                String day = LocalDate.now().plusDays(1).toString();
                evaluate("(()=>{const a=dramaAlarmApp;a.state.alarms=[a.defaultAlarm({id:'instrumentation-alarm',label:'QA alarm',repeatMode:'once',onceDate:"+JSONObject.quote(day)+",time:'12:34',enabled:true})];a.save();return true;})()");
                JSONArray scheduled = new JSONArray(preferences.getString("scheduled", "[]"));
                check("native one-time alarm scheduled", scheduled.length() == 1 && "instrumentation-alarm".equals(scheduled.getJSONObject(0).getString("alarmId")), scheduled.toString());
                evaluate("(()=>{dramaAlarmApp.state.alarms=[];dramaAlarmApp.save();return true;})()");
                check("native alarm cancellation", new JSONArray(preferences.getString("scheduled", "[]")).length() == 0);
                JSONObject valid = new JSONObject(preferences.getString("state", "{}"));
                String beforeInvalid = preferences.getString("state", "{}");
                AlarmScheduler.sync(target, "{\"schemaVersion\":8,\"alarms\":\"invalid\"}");
                check("invalid state preserves last usable schedule", beforeInvalid.equals(preferences.getString("state", "")));

                // Real AlarmManager delivery within the emulator, without sound:
                // a wake-up confirmation is delivered in 3 seconds; its audible
                // expiry is 60 seconds away and is cancelled in cleanup.
                long due = System.currentTimeMillis() + 3_000;
                JSONObject alarm = new JSONObject((String) evaluate("JSON.stringify(dramaAlarmApp.defaultAlarm({id:'instrumentation-delivery',label:'QA confirmation'}))"));
                valid.put("alarms", new JSONArray()).put("activeSession", JSONObject.NULL)
                    .put("wakeChecks", new JSONArray().put(new JSONObject().put("id", "instrumentation-check").put("status", "pending")
                        .put("dueAt", due).put("expiresAt", due + 60_000).put("alarm", alarm).put("occurrenceId", "instrumentation-occurrence")));
                evaluate("clearInterval(dramaAlarmApp.clockTimer);true");
                AlarmScheduler.sync(target, valid.toString());
                long deadline = SystemClock.uptimeMillis() + 20_000;
                boolean delivered = false;
                while (SystemClock.uptimeMillis() < deadline) {
                    if (preferences.getStringSet("fired", new HashSet<>()).contains("check:instrumentation-check")) { delivered = true; break; }
                    SystemClock.sleep(100);
                }
                check("real exact AlarmManager delivery", delivered);
                check("CPU-independent native permission status", AlarmScheduler.getStatus(target).optBoolean("exactAlarms"));

                // Exercise the lifecycle boundary with a real AlarmManager
                // delivery while the Activity is behind the launcher. A late
                // occurrence from this minute is valid within V8's ten-minute
                // catch-up rule, so no wall-clock minute wait is necessary.
                AlarmScheduler.sync(target, "{\"schemaVersion\":11,\"onboarded\":true,\"alarms\":[],\"wakeChecks\":[]}");
                runOnMainSync(() -> activity.moveTaskToBack(true));
                check("Activity enters background", until(() -> !preferences.getBoolean("foreground", true), 10_000));
                LocalDateTime minute = LocalDateTime.now().withSecond(0).withNano(0);
                long minuteAt = minute.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();
                String stamp = minute.format(DateTimeFormatter.ofPattern("HH:mm"));
                String bgId = "instrumentation-background-" + System.currentTimeMillis();
                evaluate("(()=>{const a=dramaAlarmApp;a.state.alarms=[a.defaultAlarm({id:"+JSONObject.quote(bgId)+",label:'QA background alarm',repeatMode:'once',onceDate:"+JSONObject.quote(minute.toLocalDate().toString())+",time:"+JSONObject.quote(stamp)+",enabled:true,rising:false,maxVolume:25,check:false,soundId:'morning-dew'})];a.state.activeSession=null;a.state.occurrences=[];a.state.pendingQueue=[];a.state.wakeChecks=[];a.state.lastScheduleCheckAt="+(minuteAt-1)+";a.save();return true;})()");
                check("background exact alarm starts media foreground service", until(() -> preferences.contains("ringing") && serviceRunning(), 12_000));
                check("background plays the selected packaged music instead of system default", until(() -> preferences.getBoolean("nativeAudioPlaying",false) && "bundled".equals(preferences.getString("nativeAudioSource","")) && "morning-dew".equals(preferences.getString("nativeAudioSoundId","")),12_000));
                check("background selected full music loops with correct duration", preferences.getBoolean("nativeAudioLooping",false) && Math.abs(preferences.getInt("nativeAudioDurationMs",0)-20_000)<200 && BundledAudioCatalog.assetPath(target,"morning-dew").equals(preferences.getString("nativeAudioAsset","")));
                JSONObject bgEvent = new JSONObject(preferences.getString("ringing", "{}"));
                runOnMainSync(() -> target.startActivity(new Intent(target, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)));
                check("foreground consumes background occurrence", until(() -> Boolean.TRUE.equals(evaluate("!!(dramaAlarmApp.state.activeSession && dramaAlarmApp.state.activeSession.alarm.id==="+JSONObject.quote(bgId)+")")), 12_000));
                boolean handedOver = until(() -> Boolean.TRUE.equals(evaluate("dramaAlarmApp.soundEngine.getStatus().engineReady===true")) && !preferences.contains("ringing"), 12_000);
                JSONObject audioDetails = new JSONObject((String)evaluate("JSON.stringify({audio:dramaAlarmApp.soundEngine.getStatus(),screen:dramaAlarmApp.state.screen,activeSession:dramaAlarmApp.state.activeSession,documentHidden:document.hidden,audioResumeRequired:dramaAlarmApp.state.audioResumeRequired,userActivation:navigator.userActivation?{isActive:navigator.userActivation.isActive,hasBeenActive:navigator.userActivation.hasBeenActive}:null,native:DramaAndroidHost.getStatus()})"));
                audioDetails.put("nativeRinging", preferences.getString("ringing", "null"));
                audioDetails.put("nativeForeground", preferences.getBoolean("foreground", false));
                audioDetails.put("serviceRunning", serviceRunning());
                check("WebAudio ready before native sound stops", handedOver, audioDetails.toString());
                check("native and JS occurrence ledger deduplicated", ((Number)evaluate("dramaAlarmApp.state.occurrences.filter(o=>o.alarmId==="+JSONObject.quote(bgId)+").length")).intValue() == 1);

                // Test the same action used by the notification's Emergency
                // stop. It must finish the current Web session and prevent a
                // subsequent background lifecycle transition from re-ringing.
                target.startService(new Intent(target, RingingService.class).setAction(RingingService.ACTION_STOP).putExtra("payload", bgEvent.toString()));
                check("native emergency action reaches Web session", until(() -> Boolean.TRUE.equals(evaluate("!dramaAlarmApp.state.activeSession && dramaAlarmApp.state.occurrences.some(o=>o.alarmId==="+JSONObject.quote(bgId)+" && o.status==='emergency_stopped')")), 12_000));
                AlarmScheduler.onBackground(target);
                SystemClock.sleep(250);
                check("emergency stop does not restart on background", !preferences.contains("ringing") && !serviceRunning());
                AlarmScheduler.onForeground(target);
                // An absent packaged ID must fail over once to the system alarm,
                // not silently play a different bundled premium/free track.
                JSONObject fallback = new JSONObject().put("kind","alarm").put("id","instrumentation-missing-audio")
                        .put("alarm",new JSONObject().put("soundId","missing-audio-fixture").put("rising",false).put("maxVolume",25));
                RingingService.start(target,fallback);
                check("unavailable packaged music falls back to system alarm", until(() -> preferences.getBoolean("nativeAudioPlaying",false) && "system".equals(preferences.getString("nativeAudioSource","")) && "missing-audio-fixture".equals(preferences.getString("nativeAudioSoundId","")) && !preferences.getString("nativeAudioFallbackReason","").isEmpty(),12_000));
                AlarmScheduler.stop(target);
                check("native fallback service stops without lingering audio",until(() -> !serviceRunning() && !preferences.getBoolean("nativeAudioPlaying",false),5_000));
                preferences.edit().putString("pending","[{\"id\":\"private-stale-event\"}]").putString("ringing","{\"id\":\"private-stale-event\"}").commit();
                AlarmScheduler.clearLocalData(target);
                check("local reset removes native pending events and personal schedule mirror", !preferences.contains("pending")&&!preferences.contains("state")&&!preferences.contains("ringing")&&!preferences.contains("stopped"));
                check("local reset leaves no alarm event to consume", "null".equals(AlarmScheduler.consumePending(target)));
                runOnMainSync(() -> target.startActivity(new Intent(target, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)));
                result.putString("stream", "\nPASS " + passed.size() + " Android acceptance checks\n" + String.join("\n", passed) + "\n");
                result.putString("checks", new JSONArray(passed).toString());
            } catch (Throwable error) {
                resultCode = Activity.RESULT_CANCELED;
                result.putString("stream", "\nFAIL after " + passed.size() + " checks: " + error + "\n" + android.util.Log.getStackTraceString(error));
            } finally {
                try {
                    restore();
                    if(storageSnapshotTaken && web != null) {
                        Object restoredV9=evaluate("localStorage.getItem('drama-alarm-v9')");
                        Object restoredV10=evaluate("localStorage.getItem('drama-alarm-v10')");
                        check("cleanup leaves 10.0 and 9.0 storage untouched", (originalV9Storage==null?restoredV9==null:originalV9Storage.equals(restoredV9)) && (originalV10Storage==null?restoredV10==null:originalV10Storage.equals(restoredV10)));
                    }
                    result.putString("checks", new JSONArray(passed).toString());
                    if(resultCode==Activity.RESULT_OK)result.putString("stream", "\nPASS " + passed.size() + " Android acceptance checks\n" + String.join("\n", passed) + "\n");
                } catch (Throwable error) { resultCode = Activity.RESULT_CANCELED; result.putString("cleanupError", error.toString()); }
                finish(resultCode, result);
            }
        }, "DramaAndroidAcceptance").start();
    }

    private void launch() throws Exception {
        activity = (MainActivity) startActivitySync(new Intent(getTargetContext(), MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Field field = MainActivity.class.getDeclaredField("web");
        field.setAccessible(true);
        web = (WebView) field.get(activity);
        awaitReady();
    }

    private void verifyMascotLoops(Bundle result) throws Exception {
        // Render all nine approved rigs in a visible, temporary test host. This
        // checks Chromium's real SVG animation clock and joint matrices, not
        // just the presence of animation tags in the bundle.
        evaluate("(()=>{const d=document.documentElement;window.__motionPrior={reduce:d.dataset.reduceMotion,hidden:d.dataset.pageHidden};d.dataset.reduceMotion='false';d.dataset.pageHidden='false';const box=document.createElement('div');box.id='native-motion-fixture';box.style.cssText='position:fixed;left:16px;right:16px;top:72px;height:240px;z-index:99999;display:grid;grid-template-columns:repeat(3,1fr);gap:8px;pointer-events:none';box.innerHTML=['daybreak','lunar','amber'].flatMap(theme=>['home','run','companion'].map(mode=>DramaAlarmMascot.render('idle',{theme,mode,size:56,key:'native-'+theme+'-'+mode}))).join('');document.body.append(box);DramaAlarmMascotMotion.setPaused(false);DramaAlarmMascotMotion.refresh({reduceMotion:false});window.__motionSample=()=>[...box.querySelectorAll('svg[data-v11-rig]')].map(svg=>{const part=[...svg.querySelectorAll('[data-motion-part]')].find(p=>p.querySelector(':scope > animateTransform[repeatCount=indefinite]'));const m=part?.getCTM();return {rig:svg.dataset.v11Rig,time:svg.getCurrentTime(),paused:svg.animationsPaused(),parts:svg.querySelectorAll('[data-motion-part]').length,matrix:m?[m.a,m.b,m.c,m.d,m.e,m.f]:[]};});return true;})()");
        try {
            SystemClock.sleep(200);
            JSONArray before=new JSONArray((String)evaluate("JSON.stringify(__motionSample())"));
            check("nine distinct packaged SVG loops mounted in WebView",before.length()==9);
            SystemClock.sleep(4_300);
            JSONArray after=new JSONArray((String)evaluate("JSON.stringify(__motionSample())"));
            JSONArray evidence=new JSONArray();
            for(int index=0;index<before.length();index++) {
                JSONObject first=before.getJSONObject(index),last=after.getJSONObject(index);
                boolean moved=last.getDouble("time")-first.getDouble("time")>4 && !last.optBoolean("paused") && first.getJSONArray("matrix").length()==6 && !first.getJSONArray("matrix").toString().equals(last.getJSONArray("matrix").toString());
                check("continuous local SVG joints keep moving after one full cycle: "+last.getString("rig"),moved,last.toString());
                evidence.put(new JSONObject().put("rig",last.getString("rig")).put("startTime",first.getDouble("time")).put("endTime",last.getDouble("time")).put("parts",last.optInt("parts")).put("jointChanged",moved));
            }
            JSONObject touch=new JSONObject((String)evaluate("JSON.stringify((()=>{const box=document.getElementById('native-motion-fixture'),feedback=[];for(const character of ['curtain','lamp','mouse'])for(const context of ['home','run']){const host=box.querySelector('[data-character='+character+'][data-v11-mascot='+context+']');feedback.push({character,context,responded:DramaAlarmMascotMotion.respond(host,context),feedback:host?.dataset.feedback});}return {feedback,passed:feedback.length===6&&feedback.every(item=>item.responded&&item.feedback===item.context)};})())"));
            check("all six home and morning-record touch responses start in WebView",touch.optBoolean("passed"),touch.toString());
            evaluate("DramaAlarmMascotMotion.setPaused(true);true");
            check("motion controller pauses all nine native-view rigs",Boolean.TRUE.equals(evaluate("__motionSample().every(item=>item.paused)")));
            evaluate("DramaAlarmMascotMotion.setPaused(false);true");
            result.putString("mascotLoops",evidence.toString());
            result.putString("mascotTouch",touch.getJSONArray("feedback").toString());
        } finally {
            evaluate("(()=>{document.getElementById('native-motion-fixture')?.remove();const d=document.documentElement,p=window.__motionPrior;for(const [key,value]of [['reduceMotion',p.reduce],['pageHidden',p.hidden]]){if(value===undefined)delete d.dataset[key];else d.dataset[key]=value;}DramaAlarmMascotMotion.setPaused(false);DramaAlarmMascotMotion.refresh();delete window.__motionPrior;delete window.__motionSample;return true;})()");
        }
    }

    private void verifyEmergencyLocale(Bundle result) throws Exception {
        JSONObject evidence = new JSONObject((String)evaluate("JSON.stringify((()=>{const a=dramaAlarmApp,prior=a.state,locale=DramaAlarmI18n.getLocale(),records=[];try{for(const language of ['zh-CN','en'])for(const uses of [0,3,99]){a.state={...prior,screen:'15',language,activeSession:null,emergencyUses:uses,emergencyAlternative:false,emergencyCode:''};DramaAlarmI18n.setLocale(language);a.render();const page=document.querySelector('#app>.screen'),button=page?.querySelector('[data-action=emergency-confirm-stop]');records.push({language,uses,label:button?.textContent.trim()||'',valid:!!button&&!button.disabled&&!page.querySelector('[data-hold],#emergency-stop-code')});}return {records,passed:records.length===6&&records.every(row=>row.valid)};}finally{a.state=prior;DramaAlarmI18n.setLocale(locale);a.render();}})())"));
        check("Emergency confirmation is immediately available in both languages at every use count", evidence.optBoolean("passed"), evidence.toString());
        result.putString("emergencyLocale", evidence.getJSONArray("records").toString());
    }

    private void verifyComplianceNative() throws Exception {
        check("compliance APK has an independent application identity", "com.dramaalert.android.compliance".equals(target.getPackageName()));
        check("bundled local origin is accepted", MainActivity.isBundledUri(android.net.Uri.parse("https://appassets.androidplatform.net/assets/web/index.html")));
        check("URI allowlist rejects remote hosts, cleartext, credentials, alternate ports and traversal",
                !MainActivity.isBundledUri(android.net.Uri.parse("https://example.com/assets/web/index.html"))
                && !MainActivity.isBundledUri(android.net.Uri.parse("http://appassets.androidplatform.net/assets/web/index.html"))
                && !MainActivity.isBundledUri(android.net.Uri.parse("https://user@appassets.androidplatform.net/assets/web/index.html"))
                && !MainActivity.isBundledUri(android.net.Uri.parse("https://appassets.androidplatform.net:444/assets/web/index.html"))
                && !MainActivity.isBundledUri(android.net.Uri.parse("https://appassets.androidplatform.net/assets/web/../index.html")));
        try (java.io.InputStream ignored = LocalAssetResponse.open(target,"web/index.html",null).getData()) {
            String csp=LocalAssetResponse.open(target,"web/index.html",null).getResponseHeaders().get("Content-Security-Policy");
            check("packaged HTML disallows remote scripts and frames", csp!=null&&csp.contains("script-src 'self'")&&csp.contains("frame-src 'none'"));
        }
        check("APK requests no internet or advertising-ID permission",
                target.checkSelfPermission("android.permission.INTERNET")!=android.content.pm.PackageManager.PERMISSION_GRANTED
                && target.checkSelfPermission("com.google.android.gms.permission.AD_ID")!=android.content.pm.PackageManager.PERMISSION_GRANTED);
        JSONObject item=new JSONObject().put("kind","check").put("id","compliance-check")
                .put("alarm",new JSONObject().put("label","Private label"));
        android.app.Notification followup=RingingService.notification(target,item,false);
        check("ordinary wake-up follow-up never opens full-screen",followup.fullScreenIntent==null);
        android.app.Notification ringing=RingingService.notification(target,item,true);
        check("lock-screen notifications use private visibility",followup.visibility==android.app.Notification.VISIBILITY_PRIVATE && ringing.visibility==android.app.Notification.VISIBILITY_PRIVATE);
        check("ringing notification includes an immediate native stop action",ringing.actions!=null&&ringing.actions.length==2&&ringing.actions[1].actionIntent!=null);
        check("exported launcher ignores fabricated alarm extras", !AlarmScheduler.hasActiveRinging(target));
        runOnMainSync(()->activity.onNewIntent(new Intent(target,MainActivity.class).putExtra("from_alarm",true).putExtra("payload","injected")));
        check("fabricated launch does not enable keep-screen-on",(activity.getWindow().getAttributes().flags&android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)==0);
    }

    private void verifyThemeChrome(Bundle result) throws Exception {
        evaluate("window.__chromePrior={theme:dramaAlarmApp.state.themeId,preview:dramaAlarmApp.state.themePreviewId,screen:dramaAlarmApp.state.screen,launched:document.body.classList.contains('is-launched')};document.body.classList.add('is-launched');true");
        JSONArray records=new JSONArray();
        try {
            String[][] palette={{"daybreak","#E4F3EB","#F5F8F6"},{"velvet","#F3E3ED","#FBF3EC"},{"lunar","#E7E1F3","#F2F0F9"},{"amber","#F1E2C9","#FBF3E6"}};
            for(String[] theme:palette) {
                evaluate("(()=>{const a=dramaAlarmApp;a.state.themeId="+JSONObject.quote(theme[0])+";a.state.themePreviewId=null;a.state.screen='01';a.render();DramaAndroidHost.syncChrome(true);return true;})()");
                check("system bars follow "+theme[0]+" theme",until(()->{
                    JSONObject chrome=new JSONObject((String)evaluate("JSON.stringify(DramaAndroidHost.getChromeStatus())"));
                    return theme[0].equals(chrome.optString("theme")) && theme[1].equals(chrome.optString("top")) && theme[2].equals(chrome.optString("bottom")) && chrome.optBoolean("darkIcons");
                },5_000));
                records.put(new JSONObject((String)evaluate("JSON.stringify(DramaAndroidHost.getChromeStatus())")));
                check("real system-bar icon appearance follows "+theme[0],systemIconsAreDark());
            }
            evaluate("dramaAlarmApp.state.themeId='daybreak';dramaAlarmApp.state.themePreviewId='velvet';dramaAlarmApp.render();DramaAndroidHost.syncChrome(true);true");
            check("theme preview updates native bars without applying selection",until(()->"velvet".equals(new JSONObject((String)evaluate("JSON.stringify(DramaAndroidHost.getChromeStatus())")).optString("theme")),5_000));
            evaluate("dramaAlarmApp.state.themePreviewId=null;dramaAlarmApp.render();DramaAndroidHost.syncChrome(true);true");
            check("cancelled preview restores native bars",until(()->"daybreak".equals(new JSONObject((String)evaluate("JSON.stringify(DramaAndroidHost.getChromeStatus())")).optString("theme")),5_000));
            evaluate("dramaAlarmApp.state.screen='03';dramaAlarmApp.render();DramaAndroidHost.syncChrome(true);true");
            check("dark challenge uses readable light system icons",until(()->{
                JSONObject chrome=new JSONObject((String)evaluate("JSON.stringify(DramaAndroidHost.getChromeStatus())"));
                return "dark".equals(chrome.optString("mode"))&&!chrome.optBoolean("darkIcons");
            },5_000));
            check("real dark-scene system icons use light appearance",!systemIconsAreDark());
            AtomicReference<String> geometry=new AtomicReference<>();
            runOnMainSync(()->{
                try {
                    Field field=MainActivity.class.getDeclaredField("root");field.setAccessible(true);
                    android.widget.FrameLayout root=(android.widget.FrameLayout)field.get(activity);
                    geometry.set(new JSONObject().put("rootHeight",root.getHeight()).put("webHeight",web.getHeight()).put("topPadding",root.getPaddingTop()).put("bottomPadding",root.getPaddingBottom()).put("leftPadding",root.getPaddingLeft()).put("rightPadding",root.getPaddingRight()).toString());
                } catch(Exception error){geometry.set("{}");}
            });
            JSONObject box=new JSONObject(geometry.get());
            check("one native inset owner protects status and gesture areas",box.optInt("topPadding")>0&&box.optInt("bottomPadding")>0&&box.optInt("rootHeight")-box.optInt("topPadding")-box.optInt("bottomPadding")==box.optInt("webHeight"),box.toString());
            result.putString("systemChrome",records.toString());result.putString("nativeInsets",box.toString());
        } finally {
            evaluate("(()=>{const s=window.__chromePrior,a=dramaAlarmApp;a.state.themeId=s.theme;a.state.themePreviewId=s.preview;a.state.screen=s.screen;document.body.classList.toggle('is-launched',s.launched);a.render();DramaAndroidHost.syncChrome(true);delete window.__chromePrior;return true;})()");
        }
    }

    private boolean systemIconsAreDark() {
        AtomicReference<Boolean> dark=new AtomicReference<>(false);
        runOnMainSync(()->{
            if(android.os.Build.VERSION.SDK_INT>=30) {
                android.view.WindowInsetsController controller=activity.getWindow().getInsetsController();
                int mask=android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                dark.set(controller!=null&&(controller.getSystemBarsAppearance()&mask)==mask);
            } else {
                int mask=android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                dark.set((activity.getWindow().getDecorView().getSystemUiVisibility()&mask)==mask);
            }
        });
        return dark.get();
    }

    private void verifyBundledMusic(Bundle result) throws Exception {
        JSONObject catalog;
        try(InputStream input=target.getAssets().open("web/assets/audio/catalog.json")) {
            catalog=new JSONObject(new String(bytes(input),StandardCharsets.UTF_8));
        }
        JSONArray items=catalog.getJSONArray("items"), metadata=new JSONArray();
        Set<String> ids=new HashSet<>(),sources=new HashSet<>();
        int free=0,premium=0;
        for(int index=0;index<items.length();index++) {
            JSONObject item=items.getJSONObject(index);
            String id=item.getString("id"),asset=BundledAudioCatalog.assetPath(target,id);
            if(!ids.add(id)||!sources.add(asset))throw new AssertionError("Duplicate packaged audio entry");
            if(item.getBoolean("premium"))premium++;else free++;
            MediaExtractor extractor=new MediaExtractor();
            try(AssetFileDescriptor file=target.getAssets().openFd(asset)) {
                extractor.setDataSource(file.getFileDescriptor(),file.getStartOffset(),file.getLength());
                MediaFormat format=extractor.getTrackFormat(0);
                long duration=format.getLong(MediaFormat.KEY_DURATION);
                if(!"audio/mp4a-latm".equals(format.getString(MediaFormat.KEY_MIME))||format.getInteger(MediaFormat.KEY_SAMPLE_RATE)!=44100||format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)!=2||Math.abs(duration-item.getDouble("duration")*1_000_000)>250_000)
                    throw new AssertionError("Unexpected AAC metadata "+id+": "+format);
                metadata.put(new JSONObject().put("id",id).put("asset",asset).put("durationUs",duration).put("mime",format.getString(MediaFormat.KEY_MIME)));
            } finally { extractor.release(); }
        }
        check("twelve unique AAC music files match six free and six premium catalog entries",items.length()==12&&free==6&&premium==6&&sources.size()==12);
        result.putString("musicMetadata",metadata.toString());
        String path=BundledAudioCatalog.assetPath(target,items.getJSONObject(0).getString("id"));
        byte[] full;
        try(InputStream input=target.getAssets().open(path)){full=bytes(input);}
        WebResourceResponse partial=LocalAssetResponse.open(target,path,"bytes=10-19");
        byte[] segment;
        try(InputStream input=partial.getData()){segment=bytes(input);}
        boolean same=segment.length==10;
        for(int index=0;same&&index<segment.length;index++)same=segment[index]==full[index+10];
        check("packaged M4A range responses have accurate MIME and bounded bytes",partial.getStatusCode()==206&&"audio/mp4".equals(partial.getMimeType())&&"10".equals(partial.getResponseHeaders().get("Content-Length"))&&same);
        WebResourceResponse suffix=LocalAssetResponse.open(target,path,"bytes=-5"),invalid=LocalAssetResponse.open(target,path,"bytes="+full.length+"-");
        byte[] tail;
        try(InputStream input=suffix.getData()){tail=bytes(input);}
        same=tail.length==5;
        for(int index=0;same&&index<tail.length;index++)same=tail[index]==full[full.length-5+index];
        invalid.getData().close();
        check("packaged M4A suffix and invalid ranges are handled safely",same&&suffix.getStatusCode()==206&&invalid.getStatusCode()==416);
        // This executes real WebView fetch/decode, not a synthetic oscillator
        // or a programmatic assertion that an AudioContext merely exists.
        evaluate("window.__musicDecodeQa=null;(async()=>{const context=new AudioContext();try{const response=await fetch('assets/audio/catalog.json');const catalog=await response.json();const records=[];for(const item of catalog.items){const file=await fetch(item.src);if(!file.ok||!file.headers.get('content-type').startsWith('audio/mp4'))throw Error('Audio fetch/MIME '+item.id);const buffer=await context.decodeAudioData(await file.arrayBuffer());if(Math.abs(buffer.duration-item.duration)>.25)throw Error('Audio duration '+item.id);records.push({id:item.id,duration:buffer.duration,channels:buffer.numberOfChannels});}window.__musicDecodeQa={records,ok:records.length===12};}catch(error){window.__musicDecodeQa={ok:false,error:String(error)};}finally{await context.close();}})();true");
        if(!until(()->Boolean.TRUE.equals(evaluate("!!window.__musicDecodeQa")),60_000))throw new AssertionError("WebView music decoding timed out");
        JSONObject decoded=new JSONObject((String)evaluate("JSON.stringify(window.__musicDecodeQa)"));
        check("all twelve real AAC files fetch and decode in offline Android WebView",decoded.optBoolean("ok"),decoded.toString());
        result.putString("musicWebDecode",decoded.toString());
    }

    private static byte[] bytes(InputStream input) throws Exception {
        ByteArrayOutputStream output=new ByteArrayOutputStream();
        byte[] buffer=new byte[8192];int count;
        while((count=input.read(buffer))!=-1)output.write(buffer,0,count);
        return output.toByteArray();
    }

    private void awaitReady() throws Exception {
        long deadline = SystemClock.uptimeMillis() + 60_000;
        while (SystemClock.uptimeMillis() < deadline) {
            if (Boolean.TRUE.equals(evaluate("!!(window.dramaAlarmApp && window.DramaAndroidHost && document.querySelector('#app .screen'))"))) return;
            SystemClock.sleep(100);
        }
        throw new AssertionError("Bundled WebView did not initialize within 60 seconds");
    }

    private void reloadAndAwait() throws Exception {
        // reload() returns before Chromium discards the old document. A simple
        // ready poll can otherwise observe the old app, pass, and execute its
        // next assertion while the replacement document is still loading.
        evaluate("window.__dramaQaOldDocument = true;true");
        runOnMainSync(web::reload);
        long deadline = SystemClock.uptimeMillis() + 60_000;
        while (SystemClock.uptimeMillis() < deadline) {
            if (Boolean.TRUE.equals(evaluate("!window.__dramaQaOldDocument && !!(window.dramaAlarmApp && window.DramaAndroidHost && document.querySelector('#app .screen'))"))) return;
            SystemClock.sleep(100);
        }
        throw new AssertionError("Replacement WebView document did not initialize within 60 seconds");
    }

    private Object evaluate(String script) throws Exception {
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<String> value = new AtomicReference<>();
        runOnMainSync(() -> web.evaluateJavascript(script, raw -> { value.set(raw); done.countDown(); }));
        if (!done.await(30, TimeUnit.SECONDS)) throw new AssertionError("JavaScript timeout: " + script.substring(0, Math.min(120, script.length())));
        String raw = value.get();
        if (raw == null || "undefined".equals(raw) || "null".equals(raw)) return null;
        Object decoded = new JSONTokener(raw).nextValue();
        return decoded == JSONObject.NULL ? null : decoded;
    }

    private void check(String name, boolean success) { check(name, success, ""); }
    private void check(String name, boolean success, String details) {
        if (!success) throw new AssertionError(name + (details.isEmpty() ? "" : ": " + details));
        passed.add(name);
        Bundle progress = new Bundle(); progress.putString("stream", "PASS " + name + "\n"); sendStatus(0, progress);
    }

    private interface Condition { boolean value() throws Exception; }
    private boolean until(Condition condition, long timeout) throws Exception {
        long deadline = SystemClock.uptimeMillis() + timeout;
        while (SystemClock.uptimeMillis() < deadline) {
            if (condition.value()) return true;
            SystemClock.sleep(100);
        }
        return condition.value();
    }
    @SuppressWarnings("deprecation") private boolean serviceRunning() {
        ActivityManager manager = target.getSystemService(ActivityManager.class);
        for (ActivityManager.RunningServiceInfo item : manager.getRunningServices(20)) {
            if (RingingService.class.getName().equals(item.service.getClassName())) return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked") private void restore() throws Exception {
        if (target == null || preferences == null) return;
        AlarmScheduler.stop(target);
        // Cancel the test's alarms before restoring the original native mirror.
        AlarmScheduler.sync(target, "{\"schemaVersion\":11,\"onboarded\":true,\"alarms\":[],\"wakeChecks\":[]}");
        if (web != null && storageSnapshotTaken) {
            // The outgoing document saves in beforeunload. Suppress that
            // one outgoing save so it cannot overwrite the restored record
            // with our fixture. This override vanishes with the document.
            String restoreStorage=originalStorage==null?"localStorage.removeItem('drama-alarm-v11-compliance');":"localStorage.setItem('drama-alarm-v11-compliance'," + JSONObject.quote(originalStorage) + ");";
            evaluate("(()=>{const a=window.dramaAlarmApp;if(a){a.stopRinging();a.save=()=>true;}" + restoreStorage + "return true;})()");
            reloadAndAwait();
        }
        if (originalNative != null) {
            SharedPreferences.Editor editor = preferences.edit().clear();
            for (Map.Entry<String, ?> item : originalNative.entrySet()) {
                Object value = item.getValue();
                if (value instanceof String) editor.putString(item.getKey(), (String)value);
                else if (value instanceof Boolean) editor.putBoolean(item.getKey(), (Boolean)value);
                else if (value instanceof Integer) editor.putInt(item.getKey(), (Integer)value);
                else if (value instanceof Long) editor.putLong(item.getKey(), (Long)value);
                else if (value instanceof Float) editor.putFloat(item.getKey(), (Float)value);
                else if (value instanceof Set) editor.putStringSet(item.getKey(), new HashSet<>((Set<String>)value));
            }
            editor.commit();
            AlarmScheduler.onForeground(target);
            AlarmScheduler.reschedule(target);
        }
    }
}
