package com.dramaalert.android;

/** Plain-JDK checks for the palette and single-owner inset policy. */
public final class ThemeChromeCheck {
    private static int checks;
    private static void check(boolean value,String name) {if(!value)throw new AssertionError(name);checks++;}
    public static void main(String[] args) {
        String[] themes={"daybreak","velvet","lunar","amber"};
        int[] tops={0xFFE4F3EB,0xFFF3E3ED,0xFFE7E1F3,0xFFF1E2C9};
        int[] bottoms={0xFFF5F8F6,0xFFFBF3EC,0xFFF2F0F9,0xFFFBF3E6};
        for(int index=0;index<themes.length;index++) {
            ThemeChrome chrome=ThemeChrome.resolve(themes[index],"content");
            check(chrome.top==tops[index]&&chrome.bottom==bottoms[index]&&chrome.lightSurface,"theme palette "+themes[index]);
            check(!ThemeChrome.resolve(themes[index],"dark").lightSurface,"dark icons "+themes[index]);
            ThemeChrome opening=ThemeChrome.resolve(themes[index],"launch");
            check(opening.top==opening.bottom&&!opening.lightSurface,"opening palette "+themes[index]);
        }
        check("daybreak".equals(ThemeChrome.resolve("bad-theme","bad-mode").theme),"unknown theme safe fallback");
        int[] ordinary=ThemeChrome.contentInsets(5,24,6,34,0);
        check(ordinary[0]==5&&ordinary[1]==24&&ordinary[2]==6&&ordinary[3]==34,"system bar insets");
        int[] keyboard=ThemeChrome.contentInsets(5,24,6,34,300);
        check(keyboard[3]==300,"keyboard uses max, not additive bottom insets");
        int[] invalid=ThemeChrome.contentInsets(-1,-2,-3,-4,-5);
        check(invalid[0]==0&&invalid[1]==0&&invalid[2]==0&&invalid[3]==0,"negative insets clamped");
        System.out.println("PASS "+checks+" theme/inset policy checks");
    }
}
