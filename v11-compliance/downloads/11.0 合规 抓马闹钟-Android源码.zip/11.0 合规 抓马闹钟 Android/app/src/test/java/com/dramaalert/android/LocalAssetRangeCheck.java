package com.dramaalert.android;

import java.util.Arrays;

/** Plain-Java checks for the byte-range parser; no Android service is started. */
public final class LocalAssetRangeCheck {
    public static void main(String[] arguments) {
        expect("bytes=0-9",100,new long[]{0,9});
        expect("bytes=10-",100,new long[]{10,99});
        expect("bytes=-5",100,new long[]{95,99});
        expect("bytes=-200",100,new long[]{0,99});
        expect("bytes=0-999",100,new long[]{0,99});
        expect("bytes=100-",100,null);
        expect("bytes=10-9",100,null);
        expect("bytes=-0",100,null);
        expect("bytes=+1-2",100,null);
        expect("bytes=one-two",100,null);
        expect("bytes=0-1,2-3",100,null);
        expect("bytes=0-0",0,null);
        expect("bytes=-",100,null);
        expect(null,100,null);
        if(!"audio/mp4".equals(LocalAssetResponse.mime("web/assets/audio/free-01.m4a")))throw new AssertionError("M4A MIME");
        System.out.println("PASS 15 isolated native audio range/MIME checks");
    }

    private static void expect(String range,long length,long[] wanted) {
        long[] actual=LocalAssetResponse.byteRange(range,length);
        if(!Arrays.equals(wanted,actual))throw new AssertionError(range+": "+Arrays.toString(actual));
    }
}
