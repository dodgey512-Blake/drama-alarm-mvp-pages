package com.dramaalert.android;

/** Approved app surfaces, shared by the system-bar host and device checks. */
final class ThemeChrome {
    final String theme;
    final String mode;
    final int top;
    final int bottom;
    final boolean lightSurface;

    private ThemeChrome(String theme, String mode, int top, int bottom, boolean lightSurface) {
        this.theme=theme; this.mode=mode; this.top=top; this.bottom=bottom; this.lightSurface=lightSurface;
    }

    static ThemeChrome resolve(String requestedTheme, String requestedMode) {
        String theme="velvet".equals(requestedTheme)||"lunar".equals(requestedTheme)||"amber".equals(requestedTheme)?requestedTheme:"daybreak";
        if ("launch".equals(requestedMode)) return new ThemeChrome(theme,"launch",0xFF701B2E,0xFF701B2E,false);
        if ("dark".equals(requestedMode)) {
            if ("velvet".equals(theme)) return new ThemeChrome(theme,"dark",0xFF3A2138,0xFF291A2A,false);
            if ("lunar".equals(theme)) return new ThemeChrome(theme,"dark",0xFF514866,0xFF373147,false);
            if ("amber".equals(theme)) return new ThemeChrome(theme,"dark",0xFF6F5236,0xFF453425,false);
            return new ThemeChrome(theme,"dark",0xFF173E33,0xFF112E27,false);
        }
        if ("velvet".equals(theme)) return new ThemeChrome(theme,"content",0xFFF3E3ED,0xFFFBF3EC,true);
        if ("lunar".equals(theme)) return new ThemeChrome(theme,"content",0xFFE7E1F3,0xFFF2F0F9,true);
        if ("amber".equals(theme)) return new ThemeChrome(theme,"content",0xFFF1E2C9,0xFFFBF3E6,true);
        return new ThemeChrome(theme,"content",0xFFE4F3EB,0xFFF5F8F6,true);
    }

    static int[] contentInsets(int left,int top,int right,int bottom,int keyboard) {
        return new int[]{Math.max(0,left),Math.max(0,top),Math.max(0,right),Math.max(Math.max(0,bottom),keyboard)};
    }
}
