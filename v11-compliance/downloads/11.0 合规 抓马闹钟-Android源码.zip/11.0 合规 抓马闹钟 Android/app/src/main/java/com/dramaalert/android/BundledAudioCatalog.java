package com.dramaalert.android;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/** Resolves an immutable sound ID through the same packaged catalog as the Web UI. */
final class BundledAudioCatalog {
    private BundledAudioCatalog() {}

    static String assetPath(Context context, String soundId) throws IOException, JSONException {
        if (soundId == null || soundId.isEmpty()) throw new IOException("Missing sound ID");
        JSONObject catalog;
        try (InputStream input = context.getAssets().open("web/assets/audio/catalog.json")) {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
                if (output.size() > 256_000) throw new IOException("Bundled catalog is too large");
            }
            catalog = new JSONObject(new String(output.toByteArray(), StandardCharsets.UTF_8));
        }
        JSONArray items = catalog.getJSONArray("items");
        String result = null;
        for (int index = 0; index < items.length(); index++) {
            JSONObject item = items.getJSONObject(index);
            if (!soundId.equals(item.getString("id"))) continue;
            if (result != null) throw new IOException("Ambiguous sound ID");
            String source = item.getString("src");
            if (!source.matches("assets/audio/[a-z0-9-]+\\.m4a")) throw new IOException("Invalid bundled audio path");
            result = "web/" + source;
        }
        if (result == null) throw new IOException("Sound ID is absent from the bundled catalog");
        // MediaPlayer needs a seekable APK file descriptor. M4A assets are
        // packaged uncompressed explicitly in app/build.gradle.
        try (AssetFileDescriptor file = context.getAssets().openFd(result)) {
            if (file.getLength() <= 0) throw new IOException("Empty bundled sound");
        }
        return result;
    }
}
