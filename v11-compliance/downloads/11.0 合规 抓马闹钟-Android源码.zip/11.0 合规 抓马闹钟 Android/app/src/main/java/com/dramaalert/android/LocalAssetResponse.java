package com.dramaalert.android;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** App-owned asset responses, including byte ranges for seekable packaged audio. */
final class LocalAssetResponse {
    private LocalAssetResponse() {}

    static WebResourceResponse open(Context context, String path, String range) throws IOException {
        if (path == null || path.contains("..") || path.contains("\\") || !path.startsWith("web/")) throw new IOException("Invalid asset path");
        String contentType = mime(path);
        boolean audio = contentType.startsWith("audio/");
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-cache");
        headers.put("X-Content-Type-Options", "nosniff");
        if (contentType.equals("text/html")) {
            headers.put("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self' data:; connect-src 'self'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'");
            headers.put("Referrer-Policy", "no-referrer");
        }
        String encoding = contentType.startsWith("text/") || contentType.contains("javascript") || contentType.equals("application/json") || contentType.equals("image/svg+xml") ? "UTF-8" : null;
        if (!audio) return new WebResourceResponse(contentType, encoding, 200, "OK", headers, context.getAssets().open(path));

        long length;
        try (AssetFileDescriptor file = context.getAssets().openFd(path)) { length = file.getLength(); }
        headers.put("Accept-Ranges", "bytes");
        if (range == null || range.trim().isEmpty()) {
            headers.put("Content-Length", Long.toString(length));
            return new WebResourceResponse(contentType, null, 200, "OK", headers, context.getAssets().open(path));
        }
        long[] bounds = byteRange(range, length);
        if (bounds == null) {
            headers.put("Content-Range", "bytes */" + length);
            headers.put("Content-Length", "0");
            return new WebResourceResponse(contentType, null, 416, "Range Not Satisfiable", headers, new ByteArrayInputStream(new byte[0]));
        }
        long start = bounds[0], end = bounds[1], count = end - start + 1;
        InputStream input = context.getAssets().open(path);
        try {
            long skipped = 0;
            while (skipped < start) {
                long step = input.skip(start - skipped);
                if (step == 0) { if (input.read() < 0) throw new IOException("Unexpected asset end"); step = 1; }
                skipped += step;
            }
        } catch (IOException error) { input.close(); throw error; }
        headers.put("Content-Range", "bytes " + start + "-" + end + "/" + length);
        headers.put("Content-Length", Long.toString(count));
        return new WebResourceResponse(contentType, null, 206, "Partial Content", headers, new BoundedInputStream(input, count));
    }

    static long[] byteRange(String range, long length) {
        if (length <= 0 || range == null || !range.startsWith("bytes=") || range.contains(",")) return null;
        String value = range.substring(6).trim();
        String[] parts = value.split("-", -1);
        if (parts.length != 2) return null;
        if (!parts[0].matches("[0-9]*") || !parts[1].matches("[0-9]*")) return null;
        try {
            long start, end;
            if (parts[0].isEmpty()) {
                long suffix = Long.parseLong(parts[1]);
                if (suffix <= 0) return null;
                start = Math.max(0, length - suffix); end = length - 1;
            } else {
                start = Long.parseLong(parts[0]); end = parts[1].isEmpty() ? length - 1 : Long.parseLong(parts[1]);
                if (start < 0 || start >= length || end < start) return null;
                end = Math.min(end, length - 1);
            }
            return new long[]{start, end};
        } catch (NumberFormatException ignored) { return null; }
    }

    static String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".json")) return "application/json";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
        if (path.endsWith(".woff2")) return "font/woff2";
        if (path.endsWith(".m4a")) return "audio/mp4";
        return "application/octet-stream";
    }

    private static final class BoundedInputStream extends FilterInputStream {
        private long remaining;
        BoundedInputStream(InputStream input, long count) { super(input); remaining = count; }
        @Override public int read() throws IOException { if (remaining <= 0) return -1; int value = super.read(); if (value >= 0) remaining--; return value; }
        @Override public int read(byte[] buffer, int offset, int length) throws IOException {
            if (length == 0) return 0;
            if (remaining <= 0) return -1;
            int count = super.read(buffer, offset, (int)Math.min(length, remaining));
            if (count > 0) remaining -= count;
            return count;
        }
        @Override public long skip(long count) throws IOException { long skipped = super.skip(Math.min(count, remaining)); remaining -= skipped; return skipped; }
        @Override public int available() throws IOException { return (int)Math.min(super.available(), remaining); }
    }
}
