package com.dramaalert.android;

import android.content.Context;

/** App-selected language, independent of the device language. No user data translation. */
final class LocaleText {
    private LocaleText() {}
    static boolean english(Context context) {
        return "en".equals(AlarmScheduler.prefs(context).getString("language", "zh-CN"));
    }
    static String pick(Context context, String chinese, String english) {
        return english(context) ? english : chinese;
    }
}
