package com.dramaalert.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** System lifecycle events only reschedule; playback is started from an exact alarm. */
public final class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (AlarmScheduler.ACTION_FIRE.equals(action)) {
            String payload = intent.getStringExtra(AlarmScheduler.EXTRA_PAYLOAD);
            if (payload != null) AlarmScheduler.fire(context, payload);
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || android.app.AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED.equals(action)) {
            AlarmScheduler.prefs(context).edit().putBoolean("foreground", false).apply();
            AlarmScheduler.reschedule(context);
        }
    }
}
