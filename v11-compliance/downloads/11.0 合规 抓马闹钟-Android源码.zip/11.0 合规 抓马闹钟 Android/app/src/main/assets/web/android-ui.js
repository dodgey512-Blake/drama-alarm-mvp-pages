(function(){
 'use strict';
 const original=window.DramaAlarmScreens;
 const escape=value=>String(value??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[x]);
 const t=value=>window.DramaAlarmI18n?.text(value)||value;
 const button=(label,action,secondary=false)=>`<button class="${secondary?'secondary':'primary'}" type="button" data-action="${action}">${label}</button>`;
 function notice(){
  const status=window.DramaAndroidHost?.getStatus();
  if(!status?.bridgeAvailable)return '<div class="browser-notice" role="status"><span><strong>Android host unavailable</strong><small>Open the installed app to schedule system alarms.</small></span></div>';
  if(status.exactAlarms&&status.notifications&&status.fullScreenIntent)return '';
  return `<div class="browser-notice" role="status"><span><strong>Review Android alarm access</strong><small>${!status.exactAlarms?'Precise alarm access is off. ':''}${!status.notifications?'Notifications are off. ':''}${!status.fullScreenIntent?'Full-screen alerts are off; open alarms from notifications.':''}</small></span></div>`;
 }
 function access(id,state){
  const status=window.DramaAndroidHost?.getStatus()||{};
  const row=(label,value)=>`<div class="form-row"><span>${label}</span><strong>${value?'Allowed':'Review'}</strong></div>`;
  return `<section class="screen" data-screen-id="${id}">${original.renderStatus(state)}<div class="screen-body screen-body--scroll detail-body"><div class="page-heading"><h1>Android alarm access</h1><p>Native scheduling, notifications and full-screen alerts are separate permissions.</p></div><div class="settings-card">${row('Alarms & reminders',status.exactAlarms)}${row('Alarm notifications',status.notifications)}${row('Full-screen alarm alerts',status.fullScreenIntent)}</div>${notice()}<p class="inline-help">Android schedules your saved alarms. Keep system alarm volume audible and review battery restrictions on your device.</p><div class="button-stack">${button('Review Android permissions',id==='17'?'allow-access':'refresh-access')}${button('Open Android settings','open-android-alarm-settings',true)}${id==='17'?button('Continue','permission-not-now',true):button('Back to Settings','settings-back',true)}</div></div></section>`;
 }
 const replacements=new Map([
  ['Browser permissions','Android alarm access'],['Browser notifications','Alarm notifications'],['SAVED ON THIS BROWSER','SAVED ON THIS DEVICE'],['Your alarms and results stay in this browser.','Your alarms and results stay on this device.'],
  ['This browser demo lets you set alarms, hear sounds, and practise the complete challenge.','This Android app schedules local system alarms and includes offline questions, sounds and your wake-up challenge.'],
  ['Keep this page open and your device awake. A browser can suspend or close this tab. This demo cannot promise lock-screen or background delivery.','Grant Android alarm access and review device battery restrictions. Force stopping the app prevents alarms until the app is opened again.'],
  ['For important mornings, set a backup in your device’s system Clock app.','For important mornings, test on your actual device and keep a backup system alarm until reliability has been verified.'],
  ['These checks describe this browser, not native alarm reliability or audible loudness.','These checks show Android permission and local state. Actual loudness, battery policy and hardware reliability still need a device test.'],
  ['GitHub Pages serves the website and may process normal website request information under GitHub’s privacy policy. The demo does not automatically upload your alarm labels, answers, or local events.','This APK loads local packaged files. Alarm names, answers and results stay in the app sandbox. External feedback links open outside the app.'],
  ['Browser tab only. No system alarm registration. No names or answer data included.','Android scheduling and local WebView. No names or answer data included.']
 ]);
 function render(id,state){
  if(['17','23','36'].includes(id))return access(id,state);
  let html=original.render(id,state);
  html=html.replace(/<div class="browser-notice"[^>]*>[\s\S]*?<\/div>/g,notice());
  for(const [before,after]of replacements)html=html.split(before).join(after);
  return html;
 }
 window.DramaAlarmScreens=Object.freeze({...original,render,renderPageToolbar(...args){let html=original.renderPageToolbar(...args);for(const [before,after]of replacements)html=html.split(before).join(after);return html;}});
 if(window.DramaAlarmShellRegistry){const registry={...window.DramaAlarmShellRegistry};for(const id of ['17','23','36'])registry[id]={...registry[id],title:'Android alarm access'};window.DramaAlarmShellRegistry=Object.freeze(registry);}
})();
