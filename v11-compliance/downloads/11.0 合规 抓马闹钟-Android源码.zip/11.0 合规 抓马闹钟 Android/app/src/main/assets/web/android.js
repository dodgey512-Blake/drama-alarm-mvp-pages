(function () {
  "use strict";

  // This adapter is present only in the Android package. The original V8 web
  // release and its storage remain independent from this app's local origin.
  const native = window.DramaAndroid;
  const available = Boolean(native && typeof native.getStatus === "function");
  document.documentElement.classList.add("android-app");
  let chromeSignature = "";
  let chromeFrame = 0;

  function syncChrome(force=false) {
    if (!available || typeof native.updateChrome !== "function") return;
    const app=window.dramaAlarmApp;
    const theme=document.documentElement.dataset.theme || app?.state?.themePreviewId || app?.state?.themeId || "daybreak";
    const reduced=app?.state?.reduceMotion || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const opening=document.querySelector('.launch-stage') && !document.body?.classList.contains('is-launched') && !reduced && !app?.state?.activeSession;
    const mode=opening ? 'launch' : document.querySelector('#app .screen--dark') ? 'dark' : 'content';
    const signature=theme+':'+mode;
    if(!force && signature===chromeSignature)return;
    chromeSignature=signature;
    try{native.updateChrome(theme,mode);}catch(_){chromeSignature='';}
  }
  function queueChromeSync() {
    if(chromeFrame)return;
    chromeFrame=requestAnimationFrame(()=>{chromeFrame=0;syncChrome();});
  }
  if(typeof MutationObserver==='function')new MutationObserver(queueChromeSync).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['data-theme','class']});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)syncChrome(true);});

  function readJSON(value, fallback) {
    try { return typeof value === "string" ? JSON.parse(value) : value || fallback; }
    catch (_) { return fallback; }
  }

  function status() {
    if (!available) return { notifications: false, exactAlarms: false, fullScreenIntent: false, bridgeAvailable: false };
    try { return { ...readJSON(native.getStatus(), {}), bridgeAvailable: true }; }
    catch (_) { return { notifications: false, exactAlarms: false, fullScreenIntent: false, bridgeAvailable: false }; }
  }

  function refreshStatus(app) {
    if (!app) return;
    const current = status();
    app.state.androidStatus = current;
    app.state.permission = current.notifications === true;
    app.state.permissionStatus = current.notifications ? "granted" : "denied";
  }

  function stopNative() {
    if (!available) return;
    try { native.stopRinging(); } catch (_) { /* The web challenge still has its safe stop. */ }
  }

  function drainNative(app) {
    let delivered = false;
    if (!available) return false;
    for (let index = 0; index < 100; index += 1) {
      let event;
      try { event = readJSON(native.consumePendingAlarm(), null); } catch (_) { break; }
      if (!event) break;
      delivered = true;
      app.acceptNativeAlarm(event);
    }
    return delivered;
  }

  function resume() {
    const app = window.dramaAlarmApp;
    if (!app) return;
    refreshStatus(app);
    // Drain native deliveries into the existing durable occurrence queue. Never
    // replace an active formal challenge with a second alarm.
    drainNative(app);
    app.checkScheduledAlarm(new Date());
    app.checkWakeCheckDue();
    if (app.state.activeSession && app.state.screen !== "22") {
      if (!app.soundEngine.getStatus().engineReady || app.state.audioResumeRequired) app.startRinging();
    } else stopNative();
    app.save();
    app.render();
    syncChrome(true);
  }

  window.DramaAndroidHost = Object.freeze({
    available,
    haptic(pattern, cue) {
      if (!available || typeof native.haptic !== "function") return false;
      const kind=cue==="bravo"?"success":cue==="answer"?(Array.isArray(pattern)&&pattern.length>1?"error":"success"):cue==="interaction"?(Number(pattern)<=8?"tick":"click"):["selection","tick","success","error"].includes(cue)?cue:"click";
      try { native.haptic(kind); return true; }
      catch (_) { return false; }
    },
    getStatus: status,
    syncChrome,
    getChromeStatus() {
      try{return available && typeof native.getChromeStatus==='function' ? readJSON(native.getChromeStatus(),{}) : {};}catch(_){return {};}
    },
    syncState(saved) {
      if (!available) return null;
      try { return readJSON(native.syncState(JSON.stringify(saved)), {}); }
      catch (_) { return { error: "Android alarm scheduling could not be updated. Reopen Android alarm access and try again." }; }
    },
    ready() {
      if (available) {
        try { native.nativeReady(); } catch (_) { /* onResume remains safe to call. */ }
      }
      resume();
    },
    onResume: resume,
    onPause() {
      const app = window.dramaAlarmApp;
      if (!app) return;
      app.save();
      app.stopPreview(false);
      // Native MainActivity.onPause starts the background safety sound for an
      // active session; do not call app.stopRinging(), which stops that service.
      clearInterval(app.ringRampTimer);
      clearInterval(app.ringHapticTimer);
      app.ringRampTimer = null;
      app.ringHapticTimer = null;
      app.soundEngine.stopRinging();
      if (app.state.activeSession && app.state.screen !== "22") app.state.audioResumeRequired = true;
    },
    onAlarm(event) {
      const app = window.dramaAlarmApp;
      if (!app) return;
      const parsed = readJSON(event, null);
      if (parsed) app.acceptNativeAlarm(parsed);
      resume();
    },
    onBack() {
      const app = window.dramaAlarmApp;
      return app ? app.handleAndroidBack() : false;
    },
    requestPermissions() {
      if (available) native.requestPermissions();
      else window.dramaAlarmApp?.toast("Android host is unavailable. Open the installed Android app.");
    },
    openAlarmSettings() {
      if (available) native.openAlarmSettings();
    },
    stopRinging: stopNative,
    resetLocalData() {
      if (!available || typeof native.clearLocalData !== "function") return false;
      try { native.clearLocalData(); return true; } catch (_) { return false; }
    },
    shareDiagnostics(text) {
      if (!available || typeof native.shareDiagnostics !== "function") return false;
      native.shareDiagnostics(text);
      return true;
    },
  });

  // AlarmReceiver queues foreground events without starting a second audio
  // service. A lightweight visible-only poll delivers them at the due time;
  // normal clock display refresh remains V8's stable 15-second update.
  setInterval(() => {
    const app = window.dramaAlarmApp;
    if (!document.hidden && app && drainNative(app)) {
      app.save();
      app.render();
    }
  }, 1000);
})();
