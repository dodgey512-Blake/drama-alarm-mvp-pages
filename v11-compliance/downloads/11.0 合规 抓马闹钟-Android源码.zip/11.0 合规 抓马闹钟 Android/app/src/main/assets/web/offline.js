window.DramaAlarmOffline = Object.freeze({registered:false, bundled:true, scope:"Android APK assets"});
