# 11.0 合规 抓马闹钟 Android

原生 AlarmManager、通知及后台本地音乐服务承载闹钟，WebView 提供离线产品界面。默认简体中文，可切英文。该副本使用独立 applicationId `com.dramaalert.android.compliance`，可以与原 11.0 并排安装。

## 构建

安装包为 `dist/11.0 合规 抓马闹钟.apk`。源码包为 `dist/11.0 合规 抓马闹钟-Android源码.zip`。使用 Android Debug Key 签名供 Demo 安装验证。真实商店发行需要正式签名及各项发行配置。

```sh
bash scripts/build.sh
node scripts/test-native-policy.mjs
DRAMA_ANDROID_SERIAL=emulator-5556 node scripts/accept-v11.mjs
node scripts/verify-music-package.mjs
python3 scripts/package-source.py
```

源码包已包含本地网页和十二首音乐，可直接构建。Gradle Wrapper 9.3.1、AGP 9.1.1、compileSdk 37、targetSdk 36，最低 API26。其他电脑在 Android Studio 配置本机 SDK。完整工作区才可运行 `node scripts/sync-compliance-web.mjs`，该操作通过原始网页及原生基线三方合并保留桥接逻辑。

## 已落实的范围

- 只有正在响铃的通知请求全屏。普通复查使用普通通知。
- 导出启动页只根据私有原生状态决定锁屏呈现，忽略外部伪造的响铃参数。
- 锁屏通知使用 private visibility，个人闹钟名称受系统隐私设置控制。
- 原生安全退出可以立即停止声音。网页确认退出同样可立即执行，不依赖支付、广告、使用次数或长按倒计时。
- 重置同时取消本副本计划、停止声音及清除原生事件与状态镜像。
- WebView 只加载打包的自有 HTTPS origin，显式检查域名、端口、路径及凭证，禁止远程脚本与 iframe。
- 精确闹钟授权、通知授权、全屏授权分别检查，通知通道被关闭也显示未就绪。开机仅恢复调度。
- 12 首 M4A 保持原字节、音色ID、六免费六额外曲目和原生/网页声音交接。后台播放上限10分钟，安全停止不记为答题完成。
- 没有 Internet、AD_ID、位置、相机、麦克风、共享存储或无障碍服务权限。

具体检查结果由本次 `artifacts/v11/acceptance.json` 记录。模拟器检查不能替代实体设备响度、蓝牙、OEM省电与重启、最大字体或读屏测试。真实购买及广告接入、Play权限声明和正式审核需要随后完成。iOS原生版本由独立工程实现。
